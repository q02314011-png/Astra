const { app, BrowserWindow, Menu, shell, dialog, net } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const http = require('node:http');
const { spawn } = require('node:child_process');

const isDev = !app.isPackaged && process.env.ASTRA_DEV === '1';

const PORT = Number(process.env.ASTRA_PORT) || 4000;
const LOCAL_URL = `http://127.0.0.1:${PORT}`;

let mainWindow = null;
let serverProcess = null;

/** Путь к собранному фронтенду: web/ внутри desktop, либо app/dist при разработке. */
function resolveWebRoot() {
  const candidates = [
    path.join(__dirname, 'web'),
    path.join(__dirname, '..', 'app', 'dist'),
  ];
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, 'index.html'))) return c;
  }
  return null;
}

/**
 * Путь к бэкенду, который едет вместе с приложением.
 *
 * В собранном виде сервер лежит рядом с asar (resources/server) — отдельным
 * каталогом, а не внутри архива: отдельный процесс Node не умеет читать
 * файлы из asar, а ещё там нужен package.json с "type": "module".
 */
function resolveServerEntry() {
  const candidates = [
    // собранная версия: resources/server/src/index.js
    path.join(process.resourcesPath || '', 'server', 'src', 'index.js'),
    // при разработке: desktop/server/src/index.js и server/src/index.js
    path.join(__dirname, 'server', 'src', 'index.js'),
    path.join(__dirname, '..', 'server', 'src', 'index.js'),
  ];
  return candidates.find((p) => p && fs.existsSync(p)) || null;
}

/** Короткая проверка: отвечает ли уже запущенный сервер Astra. */
function pingServer(timeoutMs = 1200) {
  return new Promise((resolve) => {
    const req = http.get(`${LOCAL_URL}/api/health`, { timeout: timeoutMs }, (res) => {
      res.resume();
      resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });
  });
}

/**
 * Поднимает бэкенд внутри приложения, если на порту ещё ничего нет.
 * Запускаем отдельным процессом через ELECTRON_RUN_AS_NODE: это тот же Node,
 * что внутри Electron, поэтому установка Node пользователю не нужна.
 */
async function startEmbeddedServer() {
  if (await pingServer()) {
    console.log(`[astra] сервер уже запущен на ${LOCAL_URL}`);
    return { ok: true, url: LOCAL_URL, external: true };
  }

  const entry = resolveServerEntry();
  if (!entry) {
    return { ok: false, url: LOCAL_URL, error: 'файл сервера не найден рядом с приложением' };
  }

  // Данные и настройки кладём в userData, а не рядом с exe:
  // папка установки в Program Files обычно защищена от записи.
  const dataDir = path.join(app.getPath('userData'), 'data');
  fs.mkdirSync(dataDir, { recursive: true });

  // Первый запуск: создаём .env в userData, чтобы ключи SMS-провайдера
  // и порт можно было менять без правки файлов в Program Files.
  const envFile = path.join(dataDir, '.env');
  const bundledEnv = path.join(path.dirname(entry), '..', '.env');
  if (!fs.existsSync(envFile)) {
    const template = fs.existsSync(bundledEnv)
      ? fs.readFileSync(bundledEnv, 'utf8')
      : [
          '# Настройки Astra. Этот файл можно свободно менять.',
          '# После правки перезапусти сервер: меню Astra -> Перезапустить сервер.',
          '',
          `PORT=${PORT}`,
          'HOST=0.0.0.0',
          '',
          '# dev  — код показывается в приложении, SMS не отправляются (бесплатно)',
          '# real — настоящие SMS через провайдера (платно, нужен ключ)',
          'SMS_MODE=dev',
          'SMS_PROVIDER=dev',
          '',
          'FIVESIM_API_KEY=',
          'SMS_ACTIVATE_API_KEY=',
          'TWILIO_ACCOUNT_SID=',
          'TWILIO_AUTH_TOKEN=',
          'TWILIO_FROM_NUMBER=',
          '',
        ].join('\n');
    try {
      fs.writeFileSync(envFile, template, 'utf8');
      console.log(`[astra] создан ${envFile}`);
    } catch (e) {
      console.error('[astra] не удалось создать .env:', e.message);
    }
  }

  return new Promise((resolve) => {
    const child = spawn(process.execPath, [entry], {
      env: {
        ...process.env,
        ELECTRON_RUN_AS_NODE: '1',
        ASTRA_DATA_DIR: dataDir,
        PORT: String(PORT),
        HOST: '0.0.0.0',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    serverProcess = child;

    child.stdout.on('data', (b) => process.stdout.write(`[server] ${b}`));
    child.stderr.on('data', (b) => process.stderr.write(`[server] ${b}`));
    child.on('error', (e) => resolve({ ok: false, url: LOCAL_URL, error: e.message }));

    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      resolve(result);
    };

    child.on('exit', (code) => {
      serverProcess = null;
      finish({
        ok: false,
        url: LOCAL_URL,
        error: `сервер завершился с кодом ${code}`,
      });
    });

    // Ждём, пока сервер начнёт отвечать.
    const deadline = Date.now() + 15000;
    const poll = async () => {
      if (Date.now() > deadline) {
        finish({ ok: false, url: LOCAL_URL, error: 'сервер не ответил за 15 секунд' });
        return;
      }
      if (await pingServer(600)) {
        finish({ ok: true, url: LOCAL_URL, external: false });
        return;
      }
      setTimeout(poll, 400);
    };
    setTimeout(poll, 600);
  });
}

function stopEmbeddedServer() {
  if (serverProcess && !serverProcess.killed) {
    try {
      serverProcess.kill();
    } catch {}
    serverProcess = null;
  }
}

function createWindow() {
  const webRoot = resolveWebRoot();

  mainWindow = new BrowserWindow({
    width: 420,
    height: 820,
    minWidth: 360,
    minHeight: 600,
    backgroundColor: '#0F0F0F',
    title: 'Astra',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });

  if (!webRoot) {
    mainWindow.loadURL(
      'data:text/html;charset=utf-8,' +
        encodeURIComponent(
          `<body style="background:#0F0F0F;color:#eee;font:16px Segoe UI;padding:40px">
             <h2>Сборка интерфейса не найдена</h2>
             <p>Сначала выполните <code>npm run build</code> в папке <b>app</b>,
             затем скопируйте <code>app/dist</code> в <code>desktop/web</code>.</p>
           </body>`,
        ),
    );
    return;
  }

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    mainWindow.loadFile(path.join(webRoot, 'index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

/** Показывает окно с результатом попытки поднять сервер. */
async function ensureServer() {
  const result = await startEmbeddedServer();
  if (result.ok) {
    const via = result.external ? 'уже был запущен' : 'запущен вместе с приложением';
    console.log(`[astra] сервер ${via}: ${result.url}`);
  } else {
    console.error('[astra] сервер не поднялся:', result.error);
    if (mainWindow) {
      dialog.showMessageBox(mainWindow, {
        type: 'warning',
        title: 'Сервер Astra',
        message: 'Не удалось запустить сервер',
        detail:
          `${result.error}\n\n` +
          'Приложение всё равно откроется — вход будет работать в автономном режиме, ' +
          'на этом же устройстве. SMS при этом не отправляются.\n\n' +
          'Адрес сервера можно изменить в настройках приложения.',
        buttons: ['Понятно'],
      });
    }
  }
  return result;
}

function buildMenu() {
  const template = [
    {
      label: 'Astra',
      submenu: [
        { role: 'reload', label: 'Обновить' },
        { role: 'forceReload', label: 'Принудительно обновить' },
        { type: 'separator' },
        { role: 'quit', label: 'Выход' },
      ],
    },
    {
      label: 'Правка',
      submenu: [
        { role: 'undo', label: 'Отменить' },
        { role: 'redo', label: 'Повторить' },
        { type: 'separator' },
        { role: 'cut', label: 'Вырезать' },
        { role: 'copy', label: 'Копировать' },
        { role: 'paste', label: 'Вставить' },
        { role: 'selectAll', label: 'Выделить всё' },
      ],
    },
    {
      label: 'Вид',
      submenu: [
        { role: 'zoomIn', label: 'Приблизить' },
        { role: 'zoomOut', label: 'Отдалить' },
        { role: 'resetZoom', label: 'Сбросить масштаб' },
        { type: 'separator' },
        { role: 'togglefullscreen', label: 'Полный экран' },
        { role: 'toggleDevTools', label: 'Инструменты разработчика' },
      ],
    },
    {
      label: 'Справка',
      submenu: [
        {
          label: 'Перезапустить сервер',
          click: async () => {
            stopEmbeddedServer();
            const r = await ensureServer();
            if (r.ok) dialog.showMessageBox(mainWindow, { type: 'info', message: `Сервер: ${r.url}` });
          },
        },
        {
          label: 'Открыть настройки сервера',
          click: () => {
            const p = path.join(app.getPath('userData'), 'data', '.env');
            fs.mkdirSync(path.dirname(p), { recursive: true });
            if (!fs.existsSync(p)) fs.writeFileSync(p, '', 'utf8');
            shell.openPath(path.dirname(p));
          },
        },
        {
          label: 'Открыть папку с данными',
          click: () => shell.openPath(app.getPath('userData')),
        },
        {
          label: 'О программе',
          click: () =>
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'О программе Astra',
              message: 'Astra 0.1.0',
              detail:
                'Тестовая версия: вход по номеру телефона с SMS-кодом.\n' +
                `Данные: ${app.getPath('userData')}`,
            }),
        },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(async () => {
  buildMenu();
  createWindow();
  // Окно появляется сразу, а сервер поднимается параллельно — не задерживаем запуск.
  await ensureServer();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('before-quit', stopEmbeddedServer);
app.on('will-quit', stopEmbeddedServer);
process.on('exit', stopEmbeddedServer);
