const { contextBridge } = require('electron');

// Приложение запущено в десктопной оболочке — фронтенд использует это
// для выбора адреса сервера по умолчанию (127.0.0.1 вместо 10.0.2.2).
contextBridge.exposeInMainWorld('__ASTRA_DESKTOP__', true);
contextBridge.exposeInMainWorld('__ASTRA_PLATFORM__', process.platform);
