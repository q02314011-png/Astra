﻿$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Admin\Desktop\Astra'
$node = 'C:\AstraToolchain\node\node.exe'
$env:Path = 'C:\AstraToolchain\node;' + $env:Path

function Log($m) { [Console]::WriteLine("==> $m") }

# ── чистка ──────────────────────────────────────────────────────
Get-Process node -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -like '*AstraToolchain*' -and $_.Id -ne $pid } |
  ForEach-Object {
    $cmd = (Get-CimInstance Win32_Process -Filter "ProcessId=$($_.Id)").CommandLine
    if ($cmd -notlike '*vite*') { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
  }
Start-Sleep 1
Remove-Item (Join-Path $root 'server\data') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $root 'desktop\server') -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:TEMP\astra-testdata" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:APPDATA\Astra" -Recurse -Force -ErrorAction SilentlyContinue

function Start-Astra([string]$label, [hashtable]$extraEnv = @{}) {
  $out = "$env:TEMP\$label.log"
  $err = "$env:TEMP\$label.err"
  foreach ($k in $extraEnv.Keys) { Set-Item -Path "env:$k" -Value $extraEnv[$k] }
  return Start-Process -FilePath $node -ArgumentList 'src/index.js' `
    -WorkingDirectory (Join-Path $root 'server') -PassThru `
    -RedirectStandardOutput $out -RedirectStandardError $err -WindowStyle Hidden
}

$h = @{ 'Content-Type' = 'application/json' }
$base = 'http://127.0.0.1:4000'

# ── 1. ASTRA_DATA_DIR уважается ─────────────────────────────────
Log 'ASTRA_DATA_DIR'
$p = Start-Astra 'a1' @{ ASTRA_DATA_DIR = "$env:TEMP\astra-testdata" }
Start-Sleep 3
$j = (Invoke-WebRequest "$base/api/auth/request-code" -Method POST -Headers $h `
  -Body '{"phone":"9991234567","country":"ru","deviceId":"d1"}' -UseBasicParsing).Content | ConvertFrom-Json
$body = '{"phone":"' + $j.phoneHint + '","code":"' + $j.devCode + '"}'
$tok = (Invoke-WebRequest "$base/api/auth/verify-code" -Method POST -Headers $h -Body $body -UseBasicParsing).Content | ConvertFrom-Json
Log ("  вход: {0}, токен {1} симв." -f $tok.user.phone, $tok.token.Length)
Log ("  БД в ASTRA_DATA_DIR: " + (Test-Path "$env:TEMP\astra-testdata\astra.json"))
Log ("  БД в server\data (не должно быть): " + (Test-Path (Join-Path $root 'server\data\astra.json')))

# ── 2. занятый порт ─────────────────────────────────────────────
Log 'порт уже занят'
$p2 = Start-Astra 'a2'
Start-Sleep 3
Log ("  второй процесс жив: " + (-not $p2.HasExited))
$err2 = Get-Content "$env:TEMP\a2.err" -Raw -ErrorAction SilentlyContinue
if ($err2) { Log '  stderr:'; ($err2.Trim() -split "`n" | Select-Object -First 6 | ForEach-Object { "    $_" }) }
Stop-Process -Id $p.Id, $p2.Id -Force -ErrorAction SilentlyContinue
Start-Sleep 1

# ── 3. автономный клиент против живого сервера, потом без него ──
Log 'сервер поднимается'
$p3 = Start-Astra 'a3'
Start-Sleep 3
$hp = (Invoke-WebRequest "$base/api/health" -UseBasicParsing).Content | ConvertFrom-Json
Log ("  health: app={0} mode={1} users={2}" -f $hp.app, $hp.mode, $hp.stats.users)
Log 'гасим сервер'
Stop-Process -Id $p3.Id -Force -ErrorAction SilentlyContinue
Start-Sleep 2
try {
  Invoke-WebRequest "$base/api/health" -UseBasicParsing -TimeoutSec 3 | Out-Null
  Log '  ОШИБКА: сервер всё ещё отвечает'
} catch {
  Log '  сервер не отвечает — так и должно быть'
}

Log 'готово'
