# Активирует тулчейн Astra в текущей сессии PowerShell.
# Использование:  . .\setup\env.ps1

$env:ASTRA_ROOT = 'C:\AstraToolchain'
$env:JAVA_HOME  = 'C:\AstraToolchain\jdk'
$env:ANDROID_HOME     = 'C:\AstraToolchain\android-sdk'
$env:ANDROID_SDK_ROOT = 'C:\AstraToolchain\android-sdk'

$env:Path = @(
  'C:\AstraToolchain\node',
  'C:\AstraToolchain\jdk\bin',
  'C:\AstraToolchain\android-sdk\platform-tools',
  'C:\AstraToolchain\android-sdk\cmdline-tools\latest\bin',
  $env:Path
) -join ';'

# npm/npx.cmd лежат в node\, но .cmd из node\ ищутся по PATHEXT
$env:Path = 'C:\AstraToolchain\node;' + $env:Path

Write-Host "node  : $((node --version 2>$null))"
Write-Host "npm   : $((npm --version 2>$null))"
Write-Host "java  : $((java -version 2>&1 | Select-Object -First 1))"
Write-Host "JAVA_HOME     = $env:JAVA_HOME"
Write-Host "ANDROID_HOME  = $env:ANDROID_HOME"
