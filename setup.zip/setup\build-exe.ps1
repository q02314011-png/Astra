﻿$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Admin\Desktop\Astra'
$env:Path = 'C:\AstraToolchain\node;' + $env:Path
$npm = 'C:\AstraToolchain\node\npm.cmd'

function Log($m) { [Console]::WriteLine("==> $m") }

Log 'build web app + copy to desktop/web'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'setup\build-web.ps1')

Log 'icons'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'setup\make-icons.ps1')

Log 'копируем сервер внутрь приложения'
$serverDest = Join-Path $root 'desktop\server'
if (Test-Path $serverDest) { Remove-Item $serverDest -Recurse -Force }
New-Item -ItemType Directory -Force -Path $serverDest | Out-Null
Copy-Item (Join-Path $root 'server\src') $serverDest -Recurse -Force
# package.json обязателен: в нём "type": "module", без него Node не поймёт ESM
Copy-Item (Join-Path $root 'server\package.json') $serverDest -Force
if (Test-Path (Join-Path $root 'server\.env')) {
  Copy-Item (Join-Path $root 'server\.env') $serverDest -Force
}
foreach ($f in Get-ChildItem $serverDest -Recurse -File) {
  "    " + $f.FullName.Replace("$root\", '')
}

# electron-builder тянет бинари electron и nsis с github — используем зеркала
$env:ELECTRON_MIRROR = 'https://npmmirror.com/mirrors/electron/'
$env:ELECTRON_BUILDER_BINARIES_MIRROR = 'https://npmmirror.com/mirrors/electron-builder-binaries/'

Log 'закрываем запущенный Astra (иначе electron-builder не сможет перезаписать exe)'
Get-Process Astra -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep 2
Get-Process Astra -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

Log 'electron-builder (portable + nsis installer)'
Push-Location (Join-Path $root 'desktop')
& $npm run dist
$code = $LASTEXITCODE
Pop-Location
if ($code -ne 0) {
  Log 'electron-builder упал. Частая причина — запущенный Astra.exe держит release\win-unpacked.'
  Log 'Закрой Astra и повтори, либо удали папку desktop\release вручную.'
  throw "electron-builder failed ($code)"
}

$release = Join-Path $root 'desktop\release'
$outDir = Join-Path $root 'dist'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
Get-ChildItem $release -Filter '*.exe' | ForEach-Object {
  Copy-Item $_.FullName $outDir -Force
  "    " + $_.Name + "  ({0:N1} MB)" -f ($_.Length / 1MB)
}

Log 'done'
