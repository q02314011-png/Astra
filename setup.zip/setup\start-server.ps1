﻿$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Admin\Desktop\Astra'
$node = 'C:\AstraToolchain\node\node.exe'

if (-not (Test-Path $node)) {
  $cmd = Get-Command node -ErrorAction SilentlyContinue
  if (-not $cmd) { throw 'node not found - run setup\dl-toolchain.ps1 first' }
  $node = $cmd.Source
}

$server = Join-Path $root 'server'
if (-not (Test-Path (Join-Path $server '.env'))) {
  Copy-Item (Join-Path $server '.env.example') (Join-Path $server '.env')
  Write-Host 'created server\.env from .env.example'
}

# Показываем адреса, по которым можно подключиться с телефона
$lan = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
  Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
  Select-Object -ExpandProperty IPAddress -Unique

Write-Host ''
Write-Host '  Astra server starting...'
Write-Host '  local : http://127.0.0.1:4000'
foreach ($ip in $lan) { Write-Host "  lan   : http://${ip}:4000" }
Write-Host ''

Push-Location $server
try { & $node src/index.js } finally { Pop-Location }
