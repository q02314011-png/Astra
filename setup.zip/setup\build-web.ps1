$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Admin\Desktop\Astra'
$env:Path = 'C:\AstraToolchain\node;' + $env:Path
$npm = 'C:\AstraToolchain\node\npm.cmd'

function Log($m) { [Console]::WriteLine("==> $m") }

Log 'build web app'
Push-Location (Join-Path $root 'app')
& $npm run build
if ($LASTEXITCODE -ne 0) { Pop-Location; throw 'vite build failed' }
Pop-Location

Log 'copy dist -> desktop/web'
$webDir = Join-Path $root 'desktop\web'
if (Test-Path $webDir) { Remove-Item $webDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $webDir | Out-Null
Copy-Item (Join-Path $root 'app\dist\*') $webDir -Recurse -Force
Get-ChildItem $webDir -Recurse -File | ForEach-Object { "    " + $_.FullName.Replace($root, '') }

if (Test-Path (Join-Path $root 'app\android\app\src\main\assets\public')) {
  Log 'sync web -> capacitor android assets'
  Push-Location (Join-Path $root 'app')
  & 'C:\AstraToolchain\node\npx.cmd' cap copy android
  Pop-Location
}

Log 'done'
