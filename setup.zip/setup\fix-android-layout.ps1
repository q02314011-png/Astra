$ErrorActionPreference = 'Stop'
$root = 'C:\AstraToolchain'
$sdk = Join-Path $root 'android-sdk'

function Log($m) {
  $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
  [Console]::WriteLine($line)
  Add-Content -Path (Join-Path $root 'setup.log') -Value $line
}

# Архивы Android SDK лежат во вложенной папке — поднимаем содержимое на уровень выше
function Flatten($targetDir) {
  $inner = Get-ChildItem $targetDir -Directory | Where-Object { $_.Name -notmatch '^(licenses|platforms|build-tools|platform-tools|cmdline-tools|tools|emulator|extras)$' } | Select-Object -First 1
  if ($inner -and (Get-ChildItem $targetDir -File -ErrorAction SilentlyContinue).Count -eq 0) {
    Log "flatten $($inner.Name) -> $targetDir"
    Get-ChildItem $inner.FullName -Force | Move-Item -Destination $targetDir -Force
    Remove-Item $inner.FullName -Recurse -Force
  }
}

Flatten (Join-Path $sdk 'platforms\android-35')
Flatten (Join-Path $sdk 'build-tools\35.0.0')
Flatten (Join-Path $sdk 'platform-tools')

# d8/apksigner/zipalign в build-tools 35 лежат как .bat и .exe
$bt = Join-Path $sdk 'build-tools\35.0.0'
if (-not (Test-Path (Join-Path $bt 'd8.bat'))) {
  $d8 = Get-ChildItem $bt -Recurse -Filter 'd8*' -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($d8 -and $d8.Name -ne 'd8.bat') { Copy-Item $d8.FullName (Join-Path $bt 'd8.bat') -Force; Log 'created d8.bat' }
}

$need = @(
  'platforms\android-35\android.jar',
  'build-tools\35.0.0\aapt2.exe',
  'build-tools\35.0.0\aapt.exe',
  'build-tools\35.0.0\d8.bat',
  'build-tools\35.0.0\apksigner.bat',
  'build-tools\35.0.0\zipalign.exe',
  'build-tools\35.0.0\lib\apksigner.jar',
  'platform-tools\adb.exe'
)

$ok = $true
foreach ($n in $need) {
  $p = Join-Path $sdk $n
  if (Test-Path $p) { Log "  ok   $n" } else { Log "  MISS $n"; $ok = $false }
}

# Заглушки .bat для aapt/apksigner (в 35 это .exe через apksigner.bat → java -jar)
Log ($(if ($ok) { '=== Android SDK ready ===' } else { '=== Android SDK INCOMPLETE ===' }))
