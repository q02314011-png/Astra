$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$root = 'C:\AstraToolchain'
$dl = Join-Path $root 'downloads'
$sdk = Join-Path $root 'android-sdk'
$mirror = 'https://mirrors.cloud.tencent.com/AndroidSDK'
New-Item -ItemType Directory -Force -Path $dl, $sdk | Out-Null

function Log($m) {
  $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
  [Console]::WriteLine($line)
  Add-Content -Path (Join-Path $root 'setup.log') -Value $line
}

function Fetch($url, $name) {
  $dest = Join-Path $dl $name
  if ((Test-Path $dest) -and (Get-Item $dest).Length -gt 1MB) {
    Log "SKIP  $name"
    return $dest
  }
  Log "GET   $name"
  $sw = [Diagnostics.Stopwatch]::StartNew()
  try {
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 3600
  } catch {
    Log "FAIL  $name : $($_.Exception.Message)"
    if (Test-Path $dest) { Remove-Item $dest -Force }
    return $null
  }
  $sw.Stop()
  Log ("DONE  {0}  {1:N1} MB  {2:N0}s" -f $name, ((Get-Item $dest).Length / 1MB), $sw.Elapsed.TotalSeconds)
  return $dest
}

function Expand-To($zip, $targetDir, $moveInner) {
  New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
  $tmp = Join-Path $dl ('x-' + [IO.Path]::GetFileNameWithoutExtension($zip))
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $zip -DestinationPath $tmp -Force
  if ($moveInner) {
    $inner = Get-ChildItem $tmp -Directory | Select-Object -First 1
    Get-ChildItem $inner.FullName -Force | Move-Item -Destination $targetDir -Force
    Remove-Item $inner.FullName -Recurse -Force
  } else {
    Get-ChildItem $tmp -Force | Move-Item -Destination $targetDir -Force
  }
  Remove-Item $tmp -Recurse -Force
}

Log '=== Android SDK install ==='

# ── platforms/android-35 ──────────────────────────────────────────
if (-not (Test-Path (Join-Path $sdk 'platforms\android-35\android.jar'))) {
  $z = Fetch "$mirror/platform-35_r02.zip" 'platform-35_r02.zip'
  if ($z) {
    Expand-To $z (Join-Path $sdk 'platforms\android-35') $false
    Log 'installed platforms/android-35'
  }
}

# ── build-tools/35.0.0 ────────────────────────────────────────────
if (-not (Test-Path (Join-Path $sdk 'build-tools\35.0.0\aapt2.exe'))) {
  $z = Fetch "$mirror/build-tools_r35_windows.zip" 'build-tools_r35_windows.zip'
  if ($z) {
    Expand-To $z (Join-Path $sdk 'build-tools\35.0.0') $false
    Log 'installed build-tools/35.0.0'
  }
}

# ── platform-tools (нужен только для adb) ─────────────────────────
if (-not (Test-Path (Join-Path $sdk 'platform-tools\adb.exe'))) {
  $z = Fetch "$mirror/platform-tools_r37.0.1-win.zip" 'platform-tools_r37.0.1-win.zip'
  if ($z) {
    Expand-To $z (Join-Path $sdk 'platform-tools') $false
    Log 'installed platform-tools'
  }
}

# ── cmdline-tools ─────────────────────────────────────────────────
if (-not (Test-Path (Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'))) {
  $z = Fetch "$mirror/commandlinetools-win-11076708_latest.zip" 'commandlinetools-win-latest.zip'
  if ($z) {
    Expand-To $z (Join-Path $sdk 'cmdline-tools\latest') $true
    Log 'installed cmdline-tools/latest'
  }
}

# ── licenses: иначе Gradle откажется собирать проект ──────────────
$lic = Join-Path $sdk 'licenses'
New-Item -ItemType Directory -Force -Path $lic | Out-Null
@'
8933bad161af4178b1185d1a37fbf41ea5269c55
d56f5187479451eabf01fb78af6dfcb131a6481e
24333f8a63b6825ea9c5514f83c2829b004d1fee
'@ | Set-Content -Path (Join-Path $lic 'android-sdk-license') -Encoding ascii
@'
84831b9409646a918e30573bab4c9c91346d8abd
504667f4c0de7af1a06de9f4b1727b84351f2910
'@ | Set-Content -Path (Join-Path $lic 'android-sdk-preview-license') -Encoding ascii
Log 'licenses written'

# ── проверка ──────────────────────────────────────────────────────
$need = @(
  'platforms\android-35\android.jar',
  'build-tools\35.0.0\aapt2.exe',
  'build-tools\35.0.0\d8.bat',
  'build-tools\35.0.0\apksigner.bat',
  'build-tools\35.0.0\zipalign.exe',
  'platform-tools\adb.exe'
)
$ok = $true
foreach ($n in $need) {
  $p = Join-Path $sdk $n
  if (Test-Path $p) { Log "  ok   $n" } else { Log "  MISS $n"; $ok = $false }
}
Log ($(if ($ok) { '=== Android SDK ready ===' } else { '=== Android SDK INCOMPLETE ===' }))
