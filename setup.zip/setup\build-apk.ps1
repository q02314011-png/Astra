$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Admin\Desktop\Astra'
$env:Path = 'C:\AstraToolchain\node;' + $env:Path

function Log($m) { [Console]::WriteLine("==> $m") }

Log 'build web app + copy to android assets'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'setup\build-web.ps1')

Log 'icons'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'setup\make-icons.ps1')

Log 'package APK (aapt2 / d8 / apksigner, no Gradle)'
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'setup\build-apk-manual.ps1')
