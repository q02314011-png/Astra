$ErrorActionPreference = 'Stop'
$root = 'C:\Users\Admin\Desktop\Astra'
$android = Join-Path $root 'app\android'
$resSrc = Join-Path $root 'app\res-icons'
$resDst = Join-Path $android 'app\src\main\res'

function Log($m) { [Console]::WriteLine("  $m") }

# ---- icons -> android res ----
foreach ($dpi in @('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi')) {
  $from = Join-Path $resSrc $dpi
  $to = Join-Path $resDst "mipmap-$dpi"
  if (-not (Test-Path $to)) { New-Item -ItemType Directory -Force -Path $to | Out-Null }
  foreach ($n in @('ic_launcher.png','ic_launcher_round.png','ic_launcher_foreground.png')) {
    $p = Join-Path $from $n
    if (Test-Path $p) { Copy-Item $p (Join-Path $to $n) -Force }
  }
  Log "icons -> mipmap-$dpi"
}

# ---- values: background color + app name ----
$values = Join-Path $resDst 'values'
New-Item -ItemType Directory -Force -Path $values | Out-Null

$icColors = Join-Path $values 'ic_launcher_background.xml'
$ic = '<?xml version="1.0" encoding="utf-8"?>' + "`n" +
      '<resources>' + "`n" +
      '    <color name="ic_launcher_background">#3390EC</color>' + "`n" +
      '</resources>' + "`n"
[System.IO.File]::WriteAllText($icColors, $ic)
Log 'values/ic_launcher_background.xml'

$strings = Join-Path $values 'strings.xml'
$st = '<?xml version="1.0" encoding="utf-8"?>' + "`n" +
      '<resources>' + "`n" +
      '    <string name="app_name">Astra</string>' + "`n" +
      '    <string name="title_activity_main">Astra</string>' + "`n" +
      '    <string name="package_name">com.astra.messenger</string>' + "`n" +
      '    <string name="custom_url_scheme">com.astra.messenger</string>' + "`n" +
      '</resources>' + "`n"
[System.IO.File]::WriteAllText($strings, $st)
Log 'values/strings.xml'

# ---- AndroidManifest: allow plain HTTP to LAN server ----
$manifest = Join-Path $android 'app\src\main\AndroidManifest.xml'
$xml = Get-Content $manifest -Raw
if ($xml -notmatch 'usesCleartextTraffic') {
  $attr = ' android:usesCleartextTraffic="true"'
  $xml = $xml.Replace('<application', '<application' + $attr)
  [System.IO.File]::WriteAllText($manifest, $xml)
  Log 'AndroidManifest.xml: usesCleartextTraffic=true'
}

# ---- versionName ----
$appGradle = Join-Path $android 'app\build.gradle'
$g = Get-Content $appGradle -Raw
$g = $g.Replace('versionName "1.0"', 'versionName "0.1.0"')
[System.IO.File]::WriteAllText($appGradle, $g)
Log 'versionName = 0.1.0'

# ---- local.properties ----
$lp = Join-Path $android 'local.properties'
[System.IO.File]::WriteAllText($lp, 'sdk.dir=C:\AstraToolchain\android-sdk' + "`n")
Log 'local.properties'

Log 'done'
