param(
  [string]$OutDir = "$(Split-Path -Parent $PSScriptRoot)"
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$OutDir = (Resolve-Path $OutDir).Path
$iconDir = Join-Path $OutDir 'desktop\build'
$resDir  = Join-Path $OutDir 'app\res-icons'
New-Item -ItemType Directory -Force -Path $iconDir, $resDir | Out-Null

# ─── Рисуем иконку Astra: синий градиентный круг + белая искра ─────
function New-AstraBitmap([int]$S, [bool]$Transparent, [double]$Scale = 1.0) {
  $bmp = New-Object System.Drawing.Bitmap($S, $S, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.Clear([System.Drawing.Color]::Transparent)

  $pad = $S * 0.06
  $r = $S * 0.5 - $pad
  $cx = $S / 2.0
  $cy = $S / 2.0

  $rect = New-Object System.Drawing.RectangleF(($cx - $r), ($cy - $r), ($r * 2), ($r * 2))
  $brush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
    $rect,
    [System.Drawing.Color]::FromArgb(255, 51, 144, 236),
    [System.Drawing.Color]::FromArgb(255, 143, 211, 244),
    55.0
  )

  if ($Transparent) {
    # круглая иконка (round / foreground) — без подложки
    $g.FillEllipse($brush, $rect)
  } else {
    $g.FillEllipse($brush, $rect)
  }

  # блик
  $hl = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
    (New-Object System.Drawing.RectangleF(0, 0, $S, $S)),
    [System.Drawing.Color]::FromArgb(90, 255, 255, 255),
    [System.Drawing.Color]::FromArgb(0, 255, 255, 255),
    60.0
  )
  $g.FillEllipse($hl, $rect)
  $hl.Dispose()

  # ── четырёхлучевая искра ──
  $outer = $r * 0.78 * $Scale
  $inner = $outer * 0.30
  $pts = New-Object 'System.Drawing.PointF[]' 8
  for ($i = 0; $i -lt 8; $i++) {
    $ang = [Math]::PI * 2 * $i / 8 - [Math]::PI / 2
    $rad = if ($i % 2 -eq 0) { $outer } else { $inner }
    $pts[$i] = New-Object System.Drawing.PointF(
      [float]($cx + $rad * [Math]::Cos($ang)),
      [float]($cy + $rad * [Math]::Sin($ang))
    )
  }
  $star = New-Object System.Drawing.Drawing2D.GraphicsPath
  $star.AddPolygon($pts)
  $starBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
  $g.FillPath($starBrush, $star)
  $starBrush.Dispose()
  $star.Dispose()
  $brush.Dispose()
  $g.Flush()
  $g.Dispose()
  return $bmp
}

function Save-Png([System.Drawing.Bitmap]$bmp, [string]$path) {
  $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
}

# ─── ICO (для electron-builder) ────────────────────────────────────
$sizes = @(16, 24, 32, 48, 64, 128, 256)
$pngs = @()
foreach ($s in $sizes) {
  $bmp = New-AstraBitmap $s $false
  $ms = New-Object System.IO.MemoryStream
  $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
  $pngs += ,@{ size = $s; data = $ms.ToArray() }
  $ms.Dispose(); $bmp.Dispose()
}

$out = New-Object System.IO.MemoryStream
$bw = New-Object System.IO.BinaryWriter($out)
$bw.Write([UInt16]0)          # reserved
$bw.Write([UInt16]1)          # type = icon
$bw.Write([UInt16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
foreach ($e in $pngs) {
  $dim = if ($e.size -ge 256) { 0 } else { $e.size }
  $bw.Write([Byte]$dim)                  # width
  $bw.Write([Byte]$dim)                  # height
  $bw.Write([Byte]0)                     # colors in palette
  $bw.Write([Byte]0)                     # reserved
  $bw.Write([UInt16]1)                   # color planes
  $bw.Write([UInt16]32)                  # bits per pixel
  $bw.Write([UInt32]$e.data.Length)
  $bw.Write([UInt32]$offset)
  $offset += $e.data.Length
}
foreach ($e in $pngs) { $bw.Write($e.data) }
$bw.Flush()
$icoPath = Join-Path $iconDir 'icon.ico'
[System.IO.File]::WriteAllBytes($icoPath, $out.ToArray())
$bw.Dispose(); $out.Dispose()
"ico  -> $icoPath ({0:N1} KB)" -f ((Get-Item $icoPath).Length / 1KB)

# ─── PNG для Android ───────────────────────────────────────────────
$dpi = @{
  'mdpi' = 48; 'hdpi' = 72; 'xhdpi' = 96; 'xxhdpi' = 144; 'xxxhdpi' = 192
}
foreach ($k in $dpi.Keys) {
  $s = $dpi[$k]
  $dir = Join-Path $resDir $k
  New-Item -ItemType Directory -Force -Path $dir | Out-Null

  $bmp = New-AstraBitmap $s $false
  Save-Png $bmp (Join-Path $dir 'ic_launcher.png')
  $bmp.Dispose()

  $bmp = New-AstraBitmap $s $false
  Save-Png $bmp (Join-Path $dir 'ic_launcher_round.png')
  $bmp.Dispose()

  # foreground: иконка занимает 60% (безопасная зона adaptive icon)
  $bmp = New-AstraBitmap ([int]($s / 0.60)) $true 0.92
  Save-Png $bmp (Join-Path $dir 'ic_launcher_foreground.png')
  $bmp.Dispose()

  "png  -> $dir ($s px)"
}

# ─── Иконка для документации / веба ───────────────────────────────
$bmp = New-AstraBitmap 512 $false
Save-Png $bmp (Join-Path $OutDir 'docs\icon-512.png')
$bmp.Dispose()
"done"
