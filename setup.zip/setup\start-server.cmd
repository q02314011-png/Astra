@echo off
chcp 65001 >nul
title Astra server
cd /d "%~dp0..\server"

set "ASTRA_NODE=C:\AstraToolchain\node\node.exe"
if not exist "%ASTRA_NODE%" set "ASTRA_NODE=node"

echo.
echo   Astra server
echo   ------------------------------------------------------------
echo   Не закрывай это окно, пока открыто приложение.
echo.

"%ASTRA_NODE%" src\index.js
if errorlevel 1 pause
