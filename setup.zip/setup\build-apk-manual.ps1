$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root       = 'C:\Users\Admin\Desktop\Astra'
$sdk        = 'C:\AstraToolchain\android-sdk'
$bt         = Join-Path $sdk 'build-tools\35.0.0'
$androidJar = Join-Path $sdk 'platforms\android-35\android.jar'
$jdk        = 'C:\AstraToolchain\jdk'

$proj   = Join-Path $root 'android-manual'
$build  = Join-Path $proj 'build'
$outDir = Join-Path $root 'dist'
$webSrc = Join-Path $root 'app\dist'
$assets = Join-Path $proj 'assets'

function Log($m) { [Console]::WriteLine("==> $m") }

function Run($exe, $argv, $label) {
  # javac/aapt2 пишут предупреждения в stderr — это не ошибка,
  # поэтому временно отключаем Stop и смотрим только на код возврата.
  $prev = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  $out = & $exe @argv 2>&1
  $code = $LASTEXITCODE
  $ErrorActionPreference = $prev
  if ($code -ne 0) {
    [Console]::WriteLine(($out | Out-String))
    throw "$label failed ($code)"
  }
  return $out
}

# ── проверки ──────────────────────────────────────────────────────
foreach ($p in @(
    $androidJar,
    (Join-Path $bt 'aapt2.exe'),
    (Join-Path $bt 'd8.bat'),
    (Join-Path $bt 'apksigner.bat'),
    (Join-Path $bt 'zipalign.exe'),
    (Join-Path $jdk 'bin\javac.exe'),
    (Join-Path $jdk 'bin\jar.exe'),
    (Join-Path $jdk 'bin\keytool.exe'))) {
  if (-not (Test-Path $p)) { throw "missing tool: $p" }
}
if (-not (Test-Path (Join-Path $webSrc 'index.html'))) {
  throw 'web build missing - run setup\build-web.ps1 first'
}
New-Item -ItemType Directory -Force -Path $build, $outDir | Out-Null

# ── 0. web-приложение -> assets/public ───────────────────────────
Log 'stage web assets'
$assetsPub = Join-Path $assets 'public'
if (Test-Path $assets) { Remove-Item $assets -Recurse -Force }
New-Item -ItemType Directory -Force -Path $assetsPub | Out-Null
Copy-Item (Join-Path $webSrc '*') $assetsPub -Recurse -Force
Log ("  {0} files" -f (Get-ChildItem $assetsPub -Recurse -File).Count)

# ── 1. чистка build ──────────────────────────────────────────────
foreach ($d in @('gen', 'classes', 'dex', 'apk')) {
  $p = Join-Path $build $d
  if (Test-Path $p) { Remove-Item $p -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $p | Out-Null
}

# ── 2. ресурсы ───────────────────────────────────────────────────
Log 'stage res'
$res = Join-Path $build 'res'
if (Test-Path $res) { Remove-Item $res -Recurse -Force }
New-Item -ItemType Directory -Force -Path $res | Out-Null

foreach ($dpi in @('mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi')) {
  $src = Join-Path $root "app\res-icons\$dpi"
  $dst = Join-Path $res "mipmap-$dpi"
  New-Item -ItemType Directory -Force -Path $dst | Out-Null
  foreach ($n in @('ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png')) {
    $p = Join-Path $src $n
    if (Test-Path $p) { Copy-Item $p (Join-Path $dst $n) -Force }
  }
}
foreach ($sub in @('values', 'mipmap-anydpi-v26')) {
  $s = Join-Path $proj "res\$sub"
  if (Test-Path $s) { Copy-Item $s $res -Recurse -Force }
}

# ── 3. aapt2 compile + link ──────────────────────────────────────
# aapt2 compile упаковывает скомпилированные ресурсы в zip-архив,
# который затем передаётся в link через -R.
Log 'aapt2 compile'
$resZip = Join-Path $build 'res.zip'
if (Test-Path $resZip) { Remove-Item $resZip -Force }
$resFiles = @(Get-ChildItem $res -Recurse -File | Where-Object { $_.Extension -eq '.xml' })
Run (Join-Path $bt 'aapt2.exe') @('compile', '--dir', $res, '-o', $resZip) 'aapt2 compile' | Out-Null
Log ("  {0} resource files -> res.zip ({1:N0} KB)" -f $resFiles.Count, ((Get-Item $resZip).Length / 1KB))

Log 'aapt2 link'
$gen = Join-Path $build 'gen'
$apkBase = Join-Path $build 'apk\base.apk'

# assets НЕ передаём через -A: на Windows aapt2 записывает их с обратными
# слэшами (assets\public\...), а Android ждёт прямые. Добавим их через jar ниже.
$linkArgs = @(
  'link',
  '-I', $androidJar,
  '--manifest', (Join-Path $proj 'res\AndroidManifest.xml'),
  '--java', $gen,
  '-R', $resZip,
  '--auto-add-overlay',
  '--min-sdk-version', '23',
  '--target-sdk-version', '34',
  '--version-code', '1',
  '--version-name', '0.1.0',
  '-o', $apkBase
)
Run (Join-Path $bt 'aapt2.exe') $linkArgs 'aapt2 link' | Out-Null
Log ("  base.apk {0:N0} KB" -f ((Get-Item $apkBase).Length / 1KB))

# ── 4. javac ─────────────────────────────────────────────────────
Log 'javac'
$classes = Join-Path $build 'classes'
$srcs = @(Get-ChildItem (Join-Path $proj 'java') -Recurse -Filter '*.java' | ForEach-Object { $_.FullName })
# android.jar идёт в classpath (bootclasspath запрещён с target 17)
$javacArgs = @(
  '-source', '17', '-target', '17',
  '-encoding', 'UTF-8',
  '-classpath', $androidJar,
  '-d', $classes, '-nowarn'
) + $srcs
Run (Join-Path $jdk 'bin\javac.exe') $javacArgs 'javac' | Out-Null
Log ("  {0} class files" -f (Get-ChildItem $classes -Recurse -Filter '*.class').Count)

# ── 5. d8 -> classes.dex ─────────────────────────────────────────
Log 'd8'
$dexDir = Join-Path $build 'dex'
$classFiles = @(Get-ChildItem $classes -Recurse -Filter '*.class' | ForEach-Object { $_.FullName })
$env:JAVA_HOME = $jdk
Run (Join-Path $bt 'd8.bat') (@('--release', '--min-api', '23', '--output', $dexDir, '--lib', $androidJar) + $classFiles) 'd8' | Out-Null
$dex = Join-Path $dexDir 'classes.dex'
if (-not (Test-Path $dex)) { throw 'classes.dex not produced' }
Log ("  classes.dex {0:N0} KB" -f ((Get-Item $dex).Length / 1KB))

# ── 6. classes.dex + assets -> APK ───────────────────────────────
Log 'package APK'
$jar = Join-Path $jdk 'bin\jar.exe'
$unsigned = Join-Path $build 'apk\unsigned.apk'
Copy-Item $apkBase $unsigned -Force

Push-Location $dexDir
try {
  & $jar uf $unsigned 'classes.dex' | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "jar classes failed ($LASTEXITCODE)" }
} finally { Pop-Location }

# jar пишет пути с прямыми слэшами — так и нужно Android
& $jar uf $unsigned -C $assets public | Out-Null
if ($LASTEXITCODE -ne 0) { throw "jar assets failed ($LASTEXITCODE)" }
Log ("  unsigned.apk {0:N0} KB" -f ((Get-Item $unsigned).Length / 1KB))

# проверяем, что пути внутри APK прямые
$check = [System.IO.Compression.ZipFile]::OpenRead($unsigned)
$bad = @($check.Entries | Where-Object { $_.FullName -like '*\*' })
$check.Dispose()
if ($bad.Count -gt 0) {
  throw ("обратные слэши в APK: " + (($bad | ForEach-Object { $_.FullName }) -join ', '))
}
Log '  entry paths ok (forward slashes)'

# ── 7. zipalign ──────────────────────────────────────────────────
Log 'zipalign'
$aligned = Join-Path $build 'apk\aligned.apk'
Run (Join-Path $bt 'zipalign.exe') @('-f', '-p', '4', $unsigned, $aligned) 'zipalign' | Out-Null

# ── 8. keystore + подпись ────────────────────────────────────────
Log 'keystore'
$ks = Join-Path $build 'astra.keystore'
if (-not (Test-Path $ks)) {
  Run (Join-Path $jdk 'bin\keytool.exe') @(
    '-genkeypair', '-v',
    '-keystore', $ks,
    '-storepass', 'astra2026', '-keypass', 'astra2026',
    '-alias', 'astra',
    '-keyalg', 'RSA', '-keysize', '2048',
    '-validity', '10950',
    '-dname', 'CN=Astra Messenger, OU=Astra, O=Astra, L=Internet, C=RU'
  ) 'keytool' | Out-Null
  Log '  created astra.keystore'
}

Log 'apksigner'
$apk = Join-Path $outDir 'Astra-0.1.0.apk'
if (Test-Path $apk) { Remove-Item $apk -Force }
Run (Join-Path $bt 'apksigner.bat') @(
  'sign',
  '--ks', $ks, '--ks-pass', 'pass:astra2026',
  '--key-pass', 'pass:astra2026',
  '--ks-key-alias', 'astra',
  '--min-sdk-version', '23',
  '--out', $apk,
  $aligned
) 'apksigner' | Out-Null

Log 'verify'
$v = Run (Join-Path $bt 'apksigner.bat') @('verify', '--print-certs', $apk) 'apksigner verify'
$v | ForEach-Object { "  $_" }

Log ("APK -> {0}" -f $apk)
Log ("size: {0:N2} MB" -f ((Get-Item $apk).Length / 1MB))
Log 'done'
