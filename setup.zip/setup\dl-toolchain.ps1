$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = 'C:\AstraToolchain'
$dl   = Join-Path $root 'downloads'
New-Item -ItemType Directory -Force -Path $dl | Out-Null

function Get-File($url, $name) {
  $dest = Join-Path $dl $name
  if (Test-Path $dest) { Write-Log "SKIP  $name (exists)"; return $dest }
  Write-Log "GET   $url"
  $sw = [Diagnostics.Stopwatch]::StartNew()
  try {
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing -TimeoutSec 3600
  } catch {
    Write-Log "FAIL  $name : $($_.Exception.Message)"
    if (Test-Path $dest) { Remove-Item $dest -Force }
    return $null
  }
  $sw.Stop()
  $mb = [math]::Round((Get-Item $dest).Length / 1MB, 1)
  Write-Log ("DONE  {0}  {1} MB  {2:N0}s" -f $name, $mb, $sw.Elapsed.TotalSeconds)
  return $dest
}

function Write-Log($m) {
  # Console::WriteLine — пишет в stdout, но НЕ в конвейер PowerShell
  $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m
  [Console]::WriteLine($line)
  Add-Content -Path (Join-Path $root 'setup.log') -Value $line
}

Write-Log '=== toolchain download started ==='

# --- Node.js LTS (windows x64 zip) ---
$nodeIdx = Invoke-WebRequest -Uri 'https://nodejs.org/dist/index.json' -UseBasicParsing -TimeoutSec 120
$nodeArr = $nodeIdx.Content | ConvertFrom-Json
$nodeVer = ($nodeArr | Where-Object { $_.lts -and $_.files -contains 'win-x64-zip' } | Select-Object -First 1).version
Write-Log "Node LTS = $nodeVer"
$nodeZip = Get-File "https://nodejs.org/dist/$nodeVer/node-$nodeVer-win-x64.zip" "node-$nodeVer-win-x64.zip"
if ($nodeZip) {
  $tgt = Join-Path $root 'node'
  if (Test-Path $tgt) { Remove-Item $tgt -Recurse -Force }
  Expand-Archive -Path $nodeZip -DestinationPath $root -Force
  Rename-Item (Join-Path $root "node-$nodeVer-win-x64") 'node' -Force
  Write-Log 'Node extracted -> C:\AstraToolchain\node'
}

# --- JDK 17 (Temurin, windows x64 zip) ---
$rel = Invoke-WebRequest -Uri 'https://api.adoptium.net/v3/assets/latest/17/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse' -UseBasicParsing -TimeoutSec 120
$assets = $rel.Content | ConvertFrom-Json
$pkg = $assets[0].binary.package
Write-Log "JDK 17 = $($pkg.name)"
$jdkZip = Get-File $pkg.link $pkg.name
if ($jdkZip) {
  $tgt = Join-Path $root 'jdk'
  if (Test-Path $tgt) { Remove-Item $tgt -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $tgt | Out-Null
  Expand-Archive -Path $jdkZip -DestinationPath $tgt -Force
  $inner = Get-ChildItem $tgt -Directory | Select-Object -First 1
  if ($inner) {
    Get-ChildItem $inner.FullName -Force | Move-Item -Destination $tgt -Force
    Remove-Item $inner.FullName -Recurse -Force
  }
  Write-Log 'JDK extracted -> C:\AstraToolchain\jdk'
}

# --- Android command-line tools (Tencent mirror) ---
$mirrors = @(
  'https://mirrors.cloud.tencent.com/AndroidSDK',
  'https://mirrors.huaweicloud.com/android/repository'
)
$clt = $null
foreach ($m in $mirrors) {
  $c = Get-File "$m/commandlinetools-win-11076708_latest.zip" 'commandlinetools-win-latest.zip'
  if ($c) { $clt = $c; Write-Log "cmdline-tools source = $m"; break }
}
if ($clt) {
  $sdk = Join-Path $root 'android-sdk'
  $tmp = Join-Path $dl 'clt-tmp'
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive -Path $clt -DestinationPath $tmp -Force
  $latest = Join-Path $sdk 'cmdline-tools\latest'
  New-Item -ItemType Directory -Force -Path $latest | Out-Null
  Get-ChildItem (Join-Path $tmp 'cmdline-tools') -Force | Move-Item -Destination $latest -Force
  Remove-Item $tmp -Recurse -Force
  Write-Log 'Android cmdline-tools -> C:\AstraToolchain\android-sdk\cmdline-tools\latest'
}

Write-Log '=== downloads phase finished ==='
