# Запуск Astra в бесплатных туннелях: работает, пока запущен твой компьютер.
#
# Нужен один раз установить cloudflared:
#   winget install --id Cloudflare.cloudflared
#
# Дальше — запустить сервер Astra и в другом окне:
#   .\setup\start-tunnel.cmd
#
# Он выдаст адрес вида https://что-то-там.trycloudflare.com
# Этот адрес вписываешь в настройках приложения на телефоне.
#
# Честно о границах:
#  - адрес меняется при каждом запуске;
#  - компьютер выключили — адрес мёртв, переписки нет;
#  - это не замена постоянному хостингу, а способ попробовать из дома и на работе.
@echo off
chcp 65001 >nul
setlocal

where cloudflared >nul 2>nul
if errorlevel 1 (
  echo.
  echo  cloudflared не найден. Установи его командой:
  echo    winget install --id Cloudflare.cloudflared
  echo.
  pause
  exit /b 1
)

echo.
echo  Запускаю туннель. Адрес появится через несколько секунд.
echo  Окно держи открытым, пока нужна переписка.
echo.

cloudflared tunnel --url http://127.0.0.1:4000