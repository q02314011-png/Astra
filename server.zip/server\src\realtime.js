/**
 * Доставка событий в реальном времени.
 *
 * Без внешних зависимостей: держим открытые long-lived HTTP-соединения и
 * пишем в них JSON построчно. Клиент читает поток через fetch + ReadableStream.
 * Это проще WebSocket и достаточно для чатов: сообщение приходит за
 * доли секунды, соединение переоткрывается автоматически.
 *
 * Соединение живёт дольше обычного прокси-таймаута, поэтому сокет не даём
 * закрыться по таймеру request'а — он живёт, пока жив клиент.
 */

const HEARTBEAT_MS = 20_000;

export const hub = {
  /** userId -> Set<res> */
  clients: new Map(),

  add(userId, res) {
    if (!this.clients.has(userId)) this.clients.set(userId, new Set());
    this.clients.get(userId).add(res);
    return () => this.remove(userId, res);
  },

  remove(userId, res) {
    const set = this.clients.get(userId);
    if (!set) return;
    set.delete(res);
    if (set.size === 0) this.clients.delete(userId);
  },

  emitToUser(userId, payload) {
    const set = this.clients.get(userId);
    if (!set || set.size === 0) return 0;
    let frame;
    try {
      frame = JSON.stringify(payload) + '\n';
    } catch {
      return 0;
    }
    let sent = 0;
    for (const res of set) {
      try {
        res.write(frame);
        sent++;
      } catch {
        set.delete(res);
      }
    }
    return sent;
  },

  /** Сколько устройств сейчас на связи у пользователя. */
  onlineUsers() {
    return this.clients.size;
  },

  isOnlineUser(userId) {
    const set = this.clients.get(userId);
    return Boolean(set && set.size);
  },

  /** Список id пользователей, которые сейчас на связи. */
  onlineIds() {
    return [...this.clients.keys()];
  },

  /** Отправляет всем подключённым: «я онлайн» / «я офлайн». */
  broadcastPresence() {
    const online = [...this.clients.keys()];
    this.emitToAll({ type: 'presence', online });
  },

  emitToAll(payload) {
    for (const userId of this.clients.keys()) this.emitToUser(userId, payload);
  },

  /** Heartbeat, чтобы прокси не рвал соединение по таймауту. */
  startHeartbeat() {
    if (this._timer) return;
    this._timer = setInterval(() => {
      for (const set of this.clients.values()) {
        for (const res of set) {
          try {
            res.write('\n'); // пустой кадр-комментарий
          } catch {
            set.delete(res);
          }
        }
      }
    }, HEARTBEAT_MS);
    this._timer.unref?.();
  },
};

/**
 * Обрабатывает GET /api/events?token=...
 * Открывает поток событий вместо обычного JSON-ответа.
 */
export function handleEvents(req, res, { userId, token }) {
  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
    'Access-Control-Allow-Origin': '*',
  });

  // Первое сообщение — клиент сразу понимает, что поток открыт.
  res.write(JSON.stringify({ type: 'hello', userId, at: Date.now() }) + '\n');

  const detach = hub.add(userId, res);
  hub.broadcastPresence();

  const cleanup = () => {
    detach();
    try {
      hub.broadcastPresence();
    } catch {}
  };
  req.on('close', cleanup);
  req.on('error', cleanup);
  res.on('error', cleanup);

  hub.startHeartbeat();
}