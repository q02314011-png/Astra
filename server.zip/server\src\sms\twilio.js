/**
 * Twilio Verify — официальный сервис SMS.
 * Ключи: https://console.twilio.com (пробный баланс ~$15)
 */
import { config } from '../config.js';

export const name = 'twilio';

const sid = () => config.twilioSid;
const basic = () => `Basic ${Buffer.from(`${sid()}:${config.twilioToken}`).toString('base64')}`;

export async function send({ phone }) {
  if (!config.twilioSid || !config.twilioToken || !config.twilioFrom) {
    return { ok: false, error: 'TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN / TWILIO_FROM_NUMBER не заданы' };
  }

  const body = new URLSearchParams({ To: phone, From: config.twilioFrom });
  const text = `Your ${config.appName} verification code is: ${'{{CODE}}'}`;

  const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid()}/Messages.json`, {
    method: 'POST',
    headers: { Authorization: basic(), 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  }).catch((e) => ({ ok: false, status: 0, json: async () => ({ message: e.message }) }));

  const j = await r.json().catch(() => ({}));
  if (!r.ok) return { ok: false, error: `Twilio: ${j.message || r.status}` };
  return {
    ok: true,
    externalId: j.sid,
    provider: 'twilio',
    pendingVerify: true, // код забираем через Verify API
    detail: `Twilio Verify to ${phone}`,
  };
}

/** Для Twilio Verify код проверяется через сервис, а не нашей таблицей. */
export async function checkCode({ phone, code }) {
  const r = await fetch(
    `https://verify.twilio.com/v2/Services/${process.env.TWILIO_VERIFY_SID || ''}/VerificationCheck`,
    {
      method: 'POST',
      headers: { Authorization: basic(), 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ To: phone, Code: code }),
    },
  ).catch((e) => ({ ok: false, json: async () => ({ status: 'failed', message: e.message }) }));
  const j = await r.json().catch(() => ({}));
  return { ok: r.ok && j.status === 'approved', error: j.message || j.status };
}

export async function check() {
  if (!config.twilioSid) return { ok: false, balance: null, detail: 'ключи не заданы' };
  const r = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid()}.json`, {
    headers: { Authorization: basic() },
  }).catch(() => null);
  if (!r) return { ok: false, balance: null, detail: 'сеть недоступна' };
  const j = await r.json().catch(() => ({}));
  return { ok: r.ok, balance: j.balance ?? null, detail: j.friendly_name || '' };
}
