import { mkdirSync, readFileSync, writeFileSync, existsSync, renameSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomUUID, randomBytes } from 'node:crypto';
import { hub } from './realtime.js';

// Каталог данных можно переопределить: сервер запускается и из CLI, и внутри
// Electron, где process.cwd() — это папка приложения, а не server/.
const DATA_DIR = resolve(process.env.ASTRA_DATA_DIR || resolve(process.cwd(), 'data'));
const DB_FILE = resolve(DATA_DIR, 'astra.json');

mkdirSync(DATA_DIR, { recursive: true });

const empty = {
  users: [],
  sessions: [],
  challenges: [],
  smsLog: [],
  chats: [],
  messages: [],
};

function load() {
  if (!existsSync(DB_FILE)) return structuredClone(empty);
  try {
    const parsed = JSON.parse(readFileSync(DB_FILE, 'utf8'));
    return { ...structuredClone(empty), ...parsed };
  } catch {
    return structuredClone(empty);
  }
}

let db = load();

function persist() {
  const tmp = `${DB_FILE}.tmp`;
  writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
  renameSync(tmp, DB_FILE);
}

const prune = () => {
  const now = Date.now();
  db.sessions = db.sessions.filter((s) => !s.expiresAt || s.expiresAt > now);
  db.challenges = db.challenges.filter(
    (c) => !c.consumedAt && (c.expiresAt || 0) + 3600_000 > now,
  );
  db.smsLog = db.smsLog.filter((r) => r.at > now - 30 * 86400_000);
};

export const store = {
  // users
  findUserByPhone(phone) {
    return db.users.find((u) => u.phone === phone) || null;
  },
  getUser(id) {
    return db.users.find((u) => u.id === id) || null;
  },
  upsertUser({ phone, name, avatarColor }) {
    let u = store.findUserByPhone(phone);
    if (!u) {
      u = {
        id: randomUUID(),
        phone,
        name: name || defaultName(phone),
        avatarColor: avatarColor || pickColor(phone),
        bio: '',
        createdAt: Date.now(),
        lastSeenAt: Date.now(),
      };
      db.users.push(u);
    } else {
      if (name) u.name = name;
      u.lastSeenAt = Date.now();
    }
    persist();
    return u;
  },
  touchUser(id) {
    const u = store.getUser(id);
    if (u) {
      u.lastSeenAt = Date.now();
      persist();
    }
  },

  listUsers() {
    return db.users;
  },

  /** Пользователь сейчас на связи (есть открытый поток событий). */
  isOnline(id) {
    return hub.isOnlineUser(id);
  },
  updateProfile(id, patch) {
    const u = store.getUser(id);
    if (!u) return null;
    if (typeof patch.name === 'string' && patch.name.trim()) u.name = patch.name.trim().slice(0, 64);
    if (typeof patch.bio === 'string') u.bio = patch.bio.slice(0, 140);
    persist();
    return u;
  },

  // sessions
  createSession(userId, ttlDays) {
    const s = {
      token: randomBytes(32).toString('hex'),
      userId,
      createdAt: Date.now(),
      expiresAt: Date.now() + ttlDays * 86400_000,
    };
    db.sessions.push(s);
    persist();
    return s;
  },
  getSession(token) {
    if (!token) return null;
    prune();
    const s = db.sessions.find((x) => x.token === token);
    if (!s || (s.expiresAt && s.expiresAt < Date.now())) return null;
    return s;
  },
  dropSession(token) {
    db.sessions = db.sessions.filter((s) => s.token !== token);
    persist();
  },

  // challenges (SMS codes)
  createChallenge({ phone, code, deviceId, ip, ttlMs = 180_000 }) {
    const c = {
      id: randomUUID(),
      phone,
      code,
      deviceId: deviceId || null,
      ip: ip || null,
      attempts: 0,
      createdAt: Date.now(),
      expiresAt: Date.now() + ttlMs,
      consumedAt: null,
    };
    db.challenges.push(c);
    persist();
    return c;
  },
  getActiveChallenge(phone) {
    prune();
    const list = db.challenges
      .filter((c) => c.phone === phone && !c.consumedAt)
      .sort((a, b) => b.createdAt - a.createdAt);
    return list[0] || null;
  },
  verifyChallenge(id, code) {
    const c = db.challenges.find((x) => x.id === id);
    if (!c) return { ok: false, reason: 'not_found' };
    if (c.consumedAt) return { ok: false, reason: 'used' };
    if (c.expiresAt < Date.now()) return { ok: false, reason: 'expired' };
    if (c.code !== code) {
      c.attempts += 1;
      if (c.attempts >= 5) c.consumedAt = Date.now();
      persist();
      return { ok: false, reason: 'mismatch' };
    }
    c.consumedAt = Date.now();
    persist();
    return { ok: true };
  },
  invalidateChallenges(phone) {
    db.challenges = db.challenges.map((c) =>
      c.phone === phone && !c.consumedAt ? { ...c, consumedAt: Date.now() } : c,
    );
    persist();
  },

  // sms log (rate limiting + diagnostics)
  logSms({ phone, ip, status, provider, externalId, text }) {
    db.smsLog.push({
      at: Date.now(),
      phone,
      ip,
      status,
      provider,
      externalId: externalId || null,
      text: text || null,
    });
    persist();
  },
  smsCountSince(phone, since) {
    return db.smsLog.filter((r) => r.phone === phone && r.at > since).length;
  },
  smsIpCountSince(ip, since) {
    return db.smsLog.filter((r) => r.ip === ip && r.at > since).length;
  },
  recentSms(limit = 20) {
    prune();
    return db.smsLog.slice(-limit).reverse();
  },

  // ── чаты ──────────────────────────────────────────────────────
  /**
   * Находит существующий диалог двух пользователей или создаёт новый.
   * Участников сортируем по id, чтобы чат не дублировался при обмене ролями.
   */
  openDirectChat(a, b) {
    const key = [a.id, b.id].sort().join('|');
    let chat = db.chats.find((c) => c.key === key);
    if (!chat) {
      chat = {
        id: randomUUID(),
        key,
        members: [a.id, b.id],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      db.chats.push(chat);
      persist();
    }
    return chat;
  },

  getChat(id) {
    return db.chats.find((c) => c.id === id) || null;
  },

  /** Список диалогов пользователя, свежие сверху. */
  listChats(userId) {
    return db.chats
      .filter((c) => c.members.includes(userId))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  },

  addMessage({ chatId, senderId, text }) {
    const msg = {
      id: randomUUID(),
      chatId,
      senderId,
      text,
      at: Date.now(),
      readAt: null,
    };
    db.messages.push(msg);
    const chat = store.getChat(chatId);
    if (chat) chat.updatedAt = msg.at;
    persist();
    return msg;
  },

  /**
   * Сообщения чата по возрастанию времени.
   * since — отсечка по id для догрузки только новых (для polling).
   */
  listMessages(chatId, { limit = 100, before = null } = {}) {
    let list = db.messages.filter((m) => m.chatId === chatId);
    if (before) list = list.filter((m) => m.at < before);
    return list.slice(-limit);
  },

  lastMessage(chatId) {
    const list = db.messages.filter((m) => m.chatId === chatId);
    return list.length ? list[list.length - 1] : null;
  },

  /** Непрочитанные: сообщения от других участников, пришедшие после lastReadAt. */
  unreadCount(chatId, userId) {
    const chat = store.getChat(chatId);
    if (!chat) return 0;
    const since = chat.readAt?.[userId] || 0;
    return db.messages.filter(
      (m) => m.chatId === chatId && m.senderId !== userId && m.at > since,
    ).length;
  },

  markRead(chatId, userId) {
    const chat = store.getChat(chatId);
    if (!chat) return 0;
    chat.readAt = chat.readAt || {};
    const now = Date.now();
    const chat_ = db.messages.filter((m) => m.chatId === chatId && m.senderId !== userId);
    const fresh = chat_.filter((m) => !m.readAt).length;
    for (const m of chat_) m.readAt = now;
    chat.readAt[userId] = now;
    persist();
    return fresh;
  },

  /** Все чаты, в которых есть непрочитанные для пользователя — для значка в списке. */
  totalUnread(userId) {
    return db.chats
      .filter((c) => c.members.includes(userId))
      .reduce((sum, c) => sum + store.unreadCount(c.id, userId), 0);
  },

  /**
   * Передаёт сообщения в реальном времени.
   *
   * Каждому участнику уходит своя копия: флаг «моё» и статус прочтения
   * зависят от того, кто смотрит. Иначе у получателя чужое сообщение
   * выглядело бы как своё.
   */
  emitMessage(chatId, message) {
    const chat = store.getChat(chatId);
    if (!chat) return;
    for (const member of chat.members) {
      hub.emitToUser(member, {
        type: 'message',
        chatId,
        message: {
          id: message.id,
          chatId: message.chatId,
          text: message.text,
          at: message.at,
          mine: message.senderId === member,
          read: Boolean(message.readAt),
        },
      });
    }
  },

  /** Сообщает участникам, что чат прочитан. */
  emitRead(chatId, byUserId) {
    const chat = store.getChat(chatId);
    if (!chat) return;
    const payload = { type: 'read', chatId, byUserId, at: Date.now() };
    for (const member of chat.members) hub.emitToUser(member, payload);
  },

  stats() {
    prune();
    return {
      users: db.users.length,
      activeSessions: db.sessions.length,
      pendingChallenges: db.challenges.filter((c) => !c.consumedAt).length,
      smsLast24h: db.smsLog.filter((r) => r.at > Date.now() - 86400_000).length,
      chats: db.chats.length,
      messages: db.messages.length,
      online: hub.onlineUsers(),
    };
  },
};

function defaultName(phone) {
  const tail = String(phone).replace(/\D/g, '').slice(-4);
  return `Astra ${tail}`;
}

const COLORS = ['#2AABEE', '#E17076', '#7BC862', '#E5CA77', '#A695E7', '#EE7AAE', '#6EC9CB', '#F2A35E'];
function pickColor(seed) {
  let h = 0;
  for (const ch of String(seed)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}
