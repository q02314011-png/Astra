// Ядро сервера. Вынесено отдельно от index.js, чтобы один и тот же код можно было
// запускать и как обычный Node-процесс, и внутри Electron (там есть свой Node).
import { createServer } from 'node:http';
import { networkInterfaces } from 'node:os';
import { config } from './config.js';
import { store } from './store.js';
import { register } from './routes/auth.js';
import { register as registerChats } from './routes/chat.js';
import * as sms from './sms/index.js';
import { COUNTRIES } from './phone.js';

// Микро-роутер: заменяет express, чтобы бэкенд был без зависимостей.
/**
 * Компилирует путь с параметрами в регулярку.
 * «/api/chats/:id/messages» -> /^\/api\/chats\/([^/]+)\/messages$/
 */
function compilePattern(pattern) {
  if (!pattern.includes(':')) return { regexp: null, keys: [] };
  const keys = [];
  const source = pattern
    .split('/')
    .map((seg) => {
      if (seg.startsWith(':')) {
        keys.push(seg.slice(1));
        return '([^/]+)';
      }
      return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');
  return { regexp: new RegExp(`^${source}$`), keys };
}

function makeApp() {
  const routes = [];
  const app = (method, pattern, handler) => {
    const { regexp, keys } = compilePattern(pattern);
    routes.push({ method, path: pattern, regexp, keys, handler });
  };
  app.get = (p, h) => app('GET', p, h);
  app.post = (p, h) => app('POST', p, h);
  app.patch = (p, h) => app('PATCH', p, h);
  app.delete = (p, h) => app('DELETE', p, h);
  app.use = (_h) => app;
  app._routes = routes;
  return app;
}

/** Ищет маршрут и достаёт параметры из пути в req.params. */
function matchRoute(routes, method, pathname) {
  for (const route of routes) {
    if (route.method !== method) continue;
    if (route.regexp) {
      const m = pathname.match(route.regexp);
      if (!m) continue;
      const params = {};
      route.keys.forEach((k, i) => {
        params[k] = decodeURIComponent(m[i + 1]);
      });
      return { route, params };
    }
    if (route.path === pathname) return { route, params: {} };
  }
  return null;
}

function send(res, status, payload) {
  if (res.headersSent) return;
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function buildRoutes() {
  const app = makeApp();

  app.get('/api/health', async (_req, res) => {
    const provider = await sms.providerStatus();
    res.json({
      ok: true,
      app: config.appName,
      version: '0.1.0',
      mode: config.smsMode,
      provider: sms.activeName(),
      providerStatus: provider,
      stats: store.stats(),
      time: new Date().toISOString(),
    });
  });

  app.get('/api/countries', (_req, res) => res.json({ ok: true, countries: COUNTRIES }));

  app.get('/api/dev/log', (_req, res) => {
    if (sms.isReal()) return res.status(403).json({ ok: false, error: 'доступно только в dev-режиме' });
    res.json({
      ok: true,
      note: 'в dev-режиме код не отправляется по SMS, а возвращается в ответе /api/auth/request-code',
      recent: store.recentSms(20).map((r) => ({
        at: new Date(r.at).toISOString(),
        phone: r.phone,
        status: r.status,
        provider: r.provider,
        text: r.text,
      })),
    });
  });

  register(app);
  registerChats(app);
  return app;
}

export function lanAddresses() {
  const out = [];
  for (const [name, list] of Object.entries(networkInterfaces())) {
    for (const ni of list || []) {
      if (ni.family === 'IPv4' && !ni.internal) out.push({ name, address: ni.address });
    }
  }
  return out;
}

/**
 * Поднимает HTTP-сервер Astra.
 * @param {{port?: number, host?: string, quiet?: boolean}} options
 * @returns {Promise<{server: import('node:http').Server, port: number, host: string, urls: string[]}>}
 */
export function startServer(options = {}) {
  const port = options.port ?? config.port;
  const host = options.host ?? config.host;
  const quiet = options.quiet ?? false;
  const app = buildRoutes();

  const server = createServer(async (req, res) => {
    const started = Date.now();
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Device-Id');
    res.setHeader('Access-Control-Max-Age', '86400');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }

    // Хелперы ответа в express-стиле: res.status(n).json({...}) и res.json({...})
    res.json = (payload, status = 200) => send(res, status, payload);
    res.status = (code) => ({ json: (payload) => send(res, code, payload) });

    // raw body -> JSON
    const chunks = [];
    let size = 0;
    for await (const c of req) {
      size += c.length;
      if (size > 1_000_000) {
        return send(res, 413, { ok: false, error: 'Слишком большой запрос' });
      }
      chunks.push(c);
    }
    const raw = Buffer.concat(chunks).toString('utf8');
    if (raw) {
      try {
        req.body = JSON.parse(raw);
      } catch {
        return send(res, 400, { ok: false, error: 'Некорректный JSON' });
      }
    } else {
      req.body = {};
    }

    const found = matchRoute(app._routes, req.method, req.url.split('?')[0]);
    if (!found) return send(res, 404, { ok: false, error: 'Не найдено', path: req.url });
    req.params = found.params;
    const { route } = found;

    try {
      await route.handler(req, res);
    } catch (e) {
      if (!quiet) console.error('[error]', req.method, req.url, e);
      if (!res.headersSent) send(res, 500, { ok: false, error: 'Внутренняя ошибка сервера' });
    } finally {
      if (!res.headersSent) send(res, 500, { ok: false, error: 'Нет ответа от обработчика' });
      if (!quiet) console.log(`${req.method} ${req.url} -> ${res.statusCode} (${Date.now() - started}ms)`);
    }
  });

  return new Promise((resolve, reject) => {
    const onEarlyError = (e) => reject(e);
    server.once('error', onEarlyError);
    server.listen(port, host, () => {
      // Дальше ошибки обрабатывает вызывающий код (index.js), а не промис.
      server.removeListener('error', onEarlyError);
      const actual = server.address();
      const realPort = typeof actual === 'object' && actual ? actual.port : port;
      const urls = [
        `http://127.0.0.1:${realPort}`,
        ...lanAddresses().map((a) => `http://${a.address}:${realPort}`),
      ];
      resolve({ server, port: realPort, host, urls });
    });
  });
}

export function bannerLines({ port, urls }) {
  const lines = [
    '',
    `  ${config.appName} — сервер запущен`,
    `  ────────────────────────────────────────────`,
    `  режим SMS : ${config.smsMode} (провайдер: ${sms.activeName()})`,
    `  локально  : http://localhost:${port}`,
  ];
  for (const a of lanAddresses()) {
    lines.push(`  в сети    : http://${a.address}:${port}   (${a.name})`);
  }
  if (sms.isReal()) {
    lines.push('  ⚠ Реальные SMS включены — SMS будут платные, оплата по тарифу провайдера.');
  } else {
    lines.push('  ℹ DEV-режим: код подтверждения показывается в приложении, реальные SMS не отправляются.');
  }
  lines.push('');
  return lines;
}
