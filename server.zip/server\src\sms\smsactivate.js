/**
 * SMS-Activate — https://sms-activate.org
 * API: https://api.sms-activate.12sms.ru/control/...
 *
 * Ключ: https://sms-activate.org/stubs/handler_api.php?api_key=&v=1&get_api_key
 */
import { config } from '../config.js';

export const name = 'sms-activate';

const API = 'https://api.sms-activate.12sms.ru/control';

const SERVICE = 'telegram';

export async function send({ phone, countryIso }) {
  if (!config.smsActivateKey) return { ok: false, error: 'SMS_ACTIVATE_API_KEY не задан' };

  const country = COUNTRY_ISO[countryIso] ?? 0; // 0 = любая страна
  const q = new URLSearchParams({
    api_key: config.smsActivateKey,
    service: SERVICE,
    operator: 'any',
    country: String(country),
  });

  let raw;
  try {
    const r = await fetch(`${API}/get-number.php?${q}`, { method: 'POST' });
    raw = (await r.text()).trim();
  } catch (e) {
    return { ok: false, error: `сеть недоступна: ${e.message}` };
  }

  if (raw.startsWith('ERROR_')) return { ok: false, error: `SMS-Activate: ${raw}` };

  const [activationId, number] = raw.split(':');
  if (!activationId || !number) return { ok: false, error: `SMS-Activate: неожиданный ответ "${raw}"` };

  const deadline = Date.now() + 90_000;
  while (Date.now() < deadline) {
    await sleep(4000);
    const st = await fetch(`${API}/get-status.php?${new URLSearchParams({
      api_key: config.smsActivateKey,
      activationId,
    })}`).then((r) => r.text()).catch(() => '');

    if (st === 'STATUS_OK') {
      const code = await fetch(`${API}/get-code.php?${new URLSearchParams({
        api_key: config.smsActivateKey,
        activationId,
      })}`).then((r) => r.text()).catch(() => '');
      const value = code.split(':')[1] || '';
      if (value) {
        return {
          ok: true,
          code: value,
          externalId: activationId,
          provider: 'sms-activate',
          detail: `номер +${number}`,
        };
      }
    }
    if (st === 'STATUS_WAIT_CODE' || st === 'STATUS_WAIT_RETRY') continue;
    if (st.startsWith('ERROR_')) return { ok: false, error: `SMS-Activate: ${st}` };
  }
  return { ok: false, error: 'SMS-Activate: таймаут ожидания SMS (90с)' };
}

export async function check() {
  if (!config.smsActivateKey) return { ok: false, balance: null, detail: 'ключ не задан' };
  const raw = await fetch(`${API}/get-balance.php?${new URLSearchParams({
    api_key: config.smsActivateKey,
  })}`).then((r) => r.text()).catch(() => '');
  if (raw.startsWith('ERROR_')) return { ok: false, balance: null, detail: raw };
  return { ok: true, balance: Number(raw), detail: 'rub' };
}

const COUNTRY_ISO = {
  ru: 0, ua: 1, kz: 2, by: 3, uz: 4, kg: 5, tj: 6, tm: 7,
  am: 8, az: 9, ge: 10, md: 11, pl: 12, de: 13, us: 2, gb: 16,
  tr: 17, fr: 18, es: 19, it: 20, br: 21, in: 22,
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
