import { config, isDevSms } from '../config.js';
import * as dev from './dev.js';
import * as fivesim from './fivesim.js';
import * as smsactivate from './smsactivate.js';
import * as twilio from './twilio.js';

const REGISTRY = { dev, fivesim, 'sms-activate': smsactivate, smsactivate, twilio };

export function active() {
  const p = isDevSms() ? 'dev' : config.smsProvider;
  return REGISTRY[p] || dev;
}

export function activeName() {
  return isDevSms() ? 'dev' : config.smsProvider;
}

export function isReal() {
  return !isDevSms();
}

/**
 * Отправляет SMS с кодом.
 * В dev-режиме код приходит сразу в ответе (SMS не отправляется).
 * В real-режиме провайдер сам присылает SMS, а код забирается по нему.
 */
export async function sendCode({ phone, countryIso, appName }) {
  const provider = active();
  const text = `${appName || config.appName}: ваш код подтверждения ${'#CODE#'}`;

  let res;
  try {
    res = await provider.send({ phone, countryIso, text, appName });
  } catch (e) {
    return { ok: false, error: `ошибка провайдера: ${e.message}` };
  }

  // Twilio Verify: код хранит сам провайдер
  if (res.pendingVerify) {
    return { ...res, text: text.replace('#CODE#', '****') };
  }

  const finalText = text.replace('#CODE#', res.code || '******');
  return { ...res, text: finalText };
}

export async function verifyWithProvider({ phone, code }) {
  const provider = active();
  if (typeof provider.checkCode === 'function' && isReal()) {
    return provider.checkCode({ phone, code });
  }
  return { ok: null }; // сверяем сами
}

export async function providerStatus() {
  try {
    return await active().check();
  } catch (e) {
    return { ok: false, balance: null, detail: e.message };
  }
}
