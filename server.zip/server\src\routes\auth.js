import { randomInt } from 'node:crypto';
import { config } from '../config.js';
import { store } from '../store.js';
import { normalizePhone, resolvePhone, isPlausible, findCountry } from '../phone.js';
import * as sms from '../sms/index.js';

const err = (res, code, message, extra = {}) =>
  res.status(code).json({ ok: false, error: message, ...extra });

function clientIp(req) {
  return (
    req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
    req.socket.remoteAddress ||
    'unknown'
  );
}

function genCode() {
  const len = config.codeLength;
  const max = 10 ** len;
  return String(randomInt(Math.ceil(max / 10), max));
}

export function register(app) {
  /**
   * POST /api/auth/request-code
   * body: { phone, country, deviceId }
   */
  app.post('/api/auth/request-code', async (req, res) => {
    const { phone: raw, country, deviceId } = req.body || {};
    const phone = resolvePhone(raw, country);

    if (!phone) return err(res, 400, 'Неверный формат номера');
    if (!isPlausible(phone, country)) {
      return err(res, 400, 'Номер не похож на номер выбранной страны');
    }

    const ip = clientIp(req);
    const now = Date.now();

    // rate limits
    if (store.smsCountSince(phone, now - 3600_000) >= config.maxSmsPerHour) {
      return err(res, 429, 'Слишком много попыток за час. Попробуйте позже.', {
        retryAfter: 3600,
      });
    }
    if (store.smsCountSince(phone, now - 86400_000) >= config.maxSmsPerDay) {
      return err(res, 429, 'Достигнут дневной лимит запросов кода.', { retryAfter: 86400 });
    }
    if (store.smsIpCountSince(ip, now - 3600_000) > 30) {
      return err(res, 429, 'Превышен лимит запросов с этого устройства.', { retryAfter: 3600 });
    }

    // resend cooldown
    const activeCh = store.getActiveChallenge(phone);
    if (activeCh) {
      const waitMs = Math.max(0, activeCh.createdAt + config.resendAfterSec * 1000 - now);
      if (waitMs > 0) {
        return res.status(200).json({
          ok: true,
          status: 'cooldown',
          retryAfter: Math.ceil(waitMs / 1000),
          expiresIn: Math.max(0, Math.ceil((activeCh.expiresAt - now) / 1000)),
          challengeId: activeCh.id,
        });
      }
    }

    const code = genCode();
    const challenge = store.createChallenge({
      phone,
      code,
      deviceId,
      ip,
      ttlMs: config.codeTtlSec * 1000,
    });

    const sent = await sms.sendCode({
      phone,
      countryIso: findCountry(country).code,
      appName: config.appName,
    });

    store.logSms({
      phone,
      ip,
      status: sent.ok ? 'sent' : 'failed',
      provider: sms.activeName(),
      externalId: sent.externalId,
      text: sent.text,
    });

    if (!sent.ok) {
      challenge.consumedAt = Date.now();
      return err(res, 502, sent.error || 'Не удалось отправить SMS', { provider: sms.activeName() });
    }

    console.log(`[auth] код для ${phone}: ${code} (${sms.activeName()})`);

    const payload = {
      ok: true,
      status: 'sent',
      provider: sms.activeName(),
      phoneHint: phone,
      expiresIn: config.codeTtlSec,
      retryAfter: config.resendAfterSec,
      challengeId: challenge.id,
    };

    // В dev-режиме отдаём код, чтобы вход работал без реальных SMS
    if (config.exposeCode && !sms.isReal()) {
      payload.devCode = code;
      payload.notice = `SMS_MODE=dev — код показан на экране вместо реального SMS (${sent.detail})`;
    }

    return res.json(payload);
  });

  /**
   * POST /api/auth/verify-code
   * body: { phone, code, name?, deviceId? }
   */
  app.post('/api/auth/verify-code', async (req, res) => {
    const { phone: raw, code, name: displayName, deviceId } = req.body || {};
    const phone = normalizePhone(raw) || resolvePhone(raw, req.body?.country);
    const digits = String(code || '').replace(/\D/g, '');

    if (!phone) return err(res, 400, 'Неверный номер');
    if (!digits) return err(res, 400, 'Введите код из SMS');

    const ch = store.getActiveChallenge(phone);
    if (!ch) {
      return err(res, 400, 'Код не найден. Запросите новый код.', { needNewCode: true });
    }
    if (ch.expiresAt < Date.now()) {
      return err(res, 400, 'Срок действия кода истёк. Запросите новый.', { needNewCode: true });
    }
    if (ch.attempts >= config.maxAttempts) {
      return err(res, 429, 'Слишком много неверных попыток. Запросите новый код.', {
        needNewCode: true,
      });
    }

    // провайдеры, которые сами проверяют код (Twilio Verify)
    if (sms.isReal() && typeof sms.verifyWithProvider === 'function') {
      const v = await sms.verifyWithProvider({ phone, code: digits });
      if (v.ok === false) {
        return err(res, 400, v.error || 'Неверный код');
      }
      if (v.ok === true) {
        const user = store.upsertUser({ phone, name: displayName });
        store.invalidateChallenges(phone);
        const session = store.createSession(user.id, config.sessionTtlDays);
        return res.json({ ok: true, token: session.token, user: publicUser(user) });
      }
    }

    const v = store.verifyChallenge(ch.id, digits);
    if (!v.ok) {
      const left = Math.max(0, config.maxAttempts - ch.attempts);
      const messages = {
        mismatch: `Неверный код${left ? `, осталось попыток: ${left}` : ''}`,
        expired: 'Срок действия кода истёк. Запросите новый.',
        used: 'Код уже использован. Запросите новый.',
        not_found: 'Код не найден. Запросите новый.',
      };
      return err(res, 400, messages[v.reason] || 'Неверный код', {
        needNewCode: ['expired', 'used', 'not_found'].includes(v.reason),
      });
    }

    const user = store.upsertUser({ phone, name: displayName });
    store.invalidateChallenges(phone);
    const session = store.createSession(user.id, config.sessionTtlDays);
    console.log(`[auth] вход: ${phone} (${user.id})`);

    return res.json({ ok: true, token: session.token, user: publicUser(user) });
  });

  /** POST /api/auth/resend — явная кнопка "Отправить код ещё раз" */
  app.post('/api/auth/resend', async (req, res) => {
    const phone = normalizePhone(req.body?.phone);
    if (!phone) return err(res, 400, 'Неверный номер');
    const ch = store.getActiveChallenge(phone);
    if (ch) {
      const waitMs = Math.max(0, ch.createdAt + config.resendAfterSec * 1000 - Date.now());
      if (waitMs > 0) {
        return res.json({ ok: true, status: 'cooldown', retryAfter: Math.ceil(waitMs / 1000) });
      }
    }
    return err(res, 400, 'Используйте /api/auth/request-code для запроса нового кода');
  });

  /** GET /api/me */
  app.get('/api/me', (req, res) => {
    const s = requireSession(req, res);
    if (!s) return;
    const user = store.getUser(s.userId);
    if (!user) return err(res, 401, 'Пользователь не найден');
    store.touchUser(user.id);
    res.json({ ok: true, user: publicUser(user) });
  });

  /** PATCH /api/me — имя/био */
  app.patch('/api/me', (req, res) => {
    const s = requireSession(req, res);
    if (!s) return;
    const user = store.updateProfile(s.userId, req.body || {});
    if (!user) return err(res, 404, 'Пользователь не найден');
    res.json({ ok: true, user: publicUser(user) });
  });

  /** POST /api/auth/logout */
  app.post('/api/auth/logout', (req, res) => {
    const token = bearer(req);
    if (token) store.dropSession(token);
    res.json({ ok: true });
  });

  return app;
}

function bearer(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : null;
}

function requireSession(req, res) {
  const session = store.getSession(bearer(req));
  if (!session) {
    err(res, 401, 'Сессия истекла. Войдите заново.');
    return null;
  }
  return session;
}

export function publicUser(u) {
  return {
    id: u.id,
    phone: u.phone,
    name: u.name,
    bio: u.bio || '',
    avatarColor: u.avatarColor,
    createdAt: u.createdAt,
  };
}
