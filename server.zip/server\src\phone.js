/** Нормализация и валидация номера телефона. */

export const COUNTRIES = [
  { code: 'ru', dial: '7', name: 'Россия', flag: '🇷🇺' },
  { code: 'ua', dial: '380', name: 'Украина', flag: '🇺🇦' },
  { code: 'by', dial: '375', name: 'Беларусь', flag: '🇧🇾' },
  { code: 'kz', dial: '7', name: 'Казахстан', flag: '🇰🇿' },
  { code: 'uz', dial: '998', name: 'Узбекистан', flag: '🇺🇿' },
  { code: 'kg', dial: '996', name: 'Кыргызстан', flag: '🇰🇬' },
  { code: 'tj', dial: '992', name: 'Таджикистан', flag: '🇹🇯' },
  { code: 'tm', dial: '993', name: 'Туркменистан', flag: '🇹🇲' },
  { code: 'am', dial: '374', name: 'Армения', flag: '🇦🇲' },
  { code: 'az', dial: '994', name: 'Азербайджан', flag: '🇦🇿' },
  { code: 'ge', dial: '995', name: 'Грузия', flag: '🇬🇪' },
  { code: 'md', dial: '373', name: 'Молдова', flag: '🇲🇩' },
  { code: 'pl', dial: '48', name: 'Польша', flag: '🇵🇱' },
  { code: 'de', dial: '49', name: 'Германия', flag: '🇩🇪' },
  { code: 'us', dial: '1', name: 'США', flag: '🇺🇸' },
  { code: 'gb', dial: '44', name: 'Великобритания', flag: '🇬🇧' },
  { code: 'tr', dial: '90', name: 'Турция', flag: '🇹🇷' },
  { code: 'fr', dial: '33', name: 'Франция', flag: '🇫🇷' },
  { code: 'es', dial: '34', name: 'Испания', flag: '🇪🇸' },
  { code: 'it', dial: '39', name: 'Италия', flag: '🇮🇹' },
  { code: 'br', dial: '55', name: 'Бразилия', flag: '🇧🇷' },
  { code: 'in', dial: '91', name: 'Индия', flag: '🇮🇳' },
];

const BY_DIAL = COUNTRIES.map((c) => ({ ...c }));

export function findCountry(iso) {
  return BY_DIAL.find((c) => c.code === String(iso || '').toLowerCase()) || BY_DIAL[0];
}

/**
 * Принимает "+7 999 123 45 67", "79991234567", "+79991234567".
 * Возвращает E.164 или null.
 */
export function normalizePhone(input) {
  if (input === undefined || input === null) return null;
  let s = String(input).trim();
  if (!s) return null;

  const hasPlus = s.startsWith('+');
  s = s.replace(/[^\d]/g, '');
  if (!s) return null;
  if (s.startsWith('00')) {
    s = s.slice(2);
  } else if (!hasPlus && s.length > 11) {
    s = s.slice(-11); // локальный формат 8XXXXXXXXXX -> 7XXXXXXXXXX поправим ниже
  }

  // Ведущий 8 для 7/380-зон: 8XXXXXXXXXX -> 7XXXXXXXXXX
  if (s.length === 11 && s.startsWith('8')) s = `7${s.slice(1)}`;

  if (s.length < 7 || s.length > 15) return null;
  return `+${s}`;
}

/** Публичное представление номера: +7 ••• ••• 45 67 */
export function maskPhone(phone) {
  const digits = String(phone).replace(/\D/g, '');
  const tail = digits.slice(-4);
  const dial = digits.length > 4 ? digits.slice(0, digits.length - 4) : '';
  const head = dial.slice(0, Math.min(3, dial.length));
  const mid = dial.slice(3);
  const midMasked = mid ? '•'.repeat(Math.min(mid.length, 3)) : '';
  return `+${head} ${midMasked} ${tail}`.trim();
}

/**
 * Клиент может прислать либо полный номер (+79991234567),
 * либо локальную часть вместе с ISO-кодом страны (9991234567 + "ru").
 * Возвращает E.164 или null.
 */
export function resolvePhone(input, countryIso) {
  const direct = normalizePhone(input);
  if (direct) {
    const c = findCountry(countryIso);
    if (c && isPlausible(direct, countryIso)) return direct;
    // если номер уже полный, но не похож на выбранную страну — всё равно берём код страны клиента
    if (!c) return direct;
  }

  const c = findCountry(countryIso);
  const digits = String(input || '').replace(/\D/g, '');
  if (!digits) return null;
  let local = digits.startsWith('00') ? digits.slice(2) : digits;
  if (local.length === 11 && local.startsWith('8')) local = local.slice(1);
  if (local.startsWith(c.dial)) return normalizePhone(local);
  if (local.length > 11) return normalizePhone(local.slice(-11));
  return normalizePhone(c.dial + local);
}

/** Грубая проверка длины локальной части после кода страны. */
export function isPlausible(phone, countryIso) {
  const c = findCountry(countryIso);
  const digits = String(phone).replace(/\D/g, '');
  if (!digits.startsWith(c.dial)) return false;
  const local = digits.slice(c.dial.length);
  return local.length >= 4 && local.length <= 12;
}
