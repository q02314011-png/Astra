/**
 * Чаты: список диалогов, создание по номеру, сообщения, прочитано.
 * Плюс /api/events — поток событий для мгновенной доставки.
 */
import { store } from '../store.js';
import { handleEvents } from '../realtime.js';
import { resolvePhone, findCountry } from '../phone.js';
import { publicUser } from './auth.js';

const err = (res, code, message, extra = {}) =>
  res.status(code).json({ ok: false, error: message, ...extra });

const bearer = (req) => {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : null;
};

function session(req) {
  const s = store.getSession(bearer(req));
  return s ? store.getUser(s.userId) : null;
}

/** В представлении чата собе��аем собеседника и последнее сообщение. */
function chatView(chat, viewerId) {
  const otherId = chat.members.find((m) => m !== viewerId) || chat.members[0];
  const other = store.getUser(otherId);
  const last = store.lastMessage(chat.id);
  return {
    id: chat.id,
    updatedAt: chat.updatedAt,
    unread: store.unreadCount(chat.id, viewerId),
    peer: other ? publicUser(other) : null,
    lastMessage: last
      ? {
          id: last.id,
          text: last.text,
          at: last.at,
          mine: last.senderId === viewerId,
        }
      : null,
  };
}

export function register(app) {
  /**
   * GET /api/events?token=...
   *
   * Токен в query, потому что EventSource не умеет заголовки,
   * а мы держим поток вручную через fetch.
   */
  app.get('/api/events', (req, res) => {
    const token = req.url.includes('token=')
      ? decodeURIComponent(req.url.split('token=')[1].split('&')[0])
      : bearer(req);
    const s = store.getSession(token);
    if (!s) {
      // Поток уже нельзя перевести в 401 после первого байта, поэтому отвечаем сразу.
      return err(res, 401, 'Сессия истекла');
    }
    const user = store.getUser(s.userId);
    if (!user) return err(res, 401, 'Пользователь не найден');
    handleEvents(req, res, { userId: user.id, token });
  });

  /** GET /api/chats — список диалогов с последним сообщением. */
  app.get('/api/chats', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const chats = store.listChats(me.id).map((c) => chatView(c, me.id));
    return res.json({ ok: true, chats, unreadTotal: store.totalUnread(me.id) });
  });

  /**
   * POST /api/chats — начать переписку по номеру телефона.
   * body: { phone, country? }
   */
  app.post('/api/chats', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const { phone: raw, country } = req.body || {};
    const phone = resolvePhone(raw, country);
    if (!phone) return err(res, 400, 'Неверный формат номера');

    const peer = store.findUserByPhone(phone);
    if (!peer) {
      const pretty = `+${phone.replace(/^\+/, '')}`;
      return err(res, 404, `Номер ${pretty} ещё не зарегистрирован в Astra`, {
        phone: pretty,
        hint: 'Попроси друга установить Astra и войти — тогда чат появится.',
      });
    }
    if (peer.id === me.id) {
      return err(res, 400, 'Нельзя начать чат с самим собой');
    }

    const chat = store.openDirectChat(me, peer);
    store.touchUser(me.id);
    return res.json({ ok: true, chat: chatView(chat, me.id) });
  });

  /** GET /api/chats/:id — один диалог. */
  app.get('/api/chats/:id', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const chat = store.getChat(req.params.id);
    if (!chat) return err(res, 404, 'Чат не найден');
    if (!chat.members.includes(me.id)) return err(res, 403, 'Это не ваш чат');

    return res.json({ ok: true, chat: chatView(chat, me.id) });
  });

  /**
   * GET /api/chats/:id/messages?limit=&before=
   * before — метка времени, чтобы догрузить историю вверх.
   */
  app.get('/api/chats/:id/messages', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const chat = store.getChat(req.params.id);
    if (!chat) return err(res, 404, 'Чат не найден');
    if (!chat.members.includes(me.id)) return err(res, 403, 'Это не ваш чат');

    const url = new URL(req.url, 'http://x');
    const limit = Math.min(200, Number(url.searchParams.get('limit')) || 100);
    const before = url.searchParams.get('before')
      ? Number(url.searchParams.get('before'))
      : null;

    const list = store.listMessages(chat.id, { limit, before });
    return res.json({
      ok: true,
      messages: list.map((m) => ({
        id: m.id,
        chatId: m.chatId,
        text: m.text,
        at: m.at,
        mine: m.senderId === me.id,
        read: Boolean(m.readAt),
      })),
      hasMore: list.length === limit,
    });
  });

  /**
   * POST /api/chats/:id/messages
   * body: { text }
   */
  app.post('/api/chats/:id/messages', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const chat = store.getChat(req.params.id);
    if (!chat) return err(res, 404, 'Чат не найден');
    if (!chat.members.includes(me.id)) return err(res, 403, 'Это не ваш чат');

    const text = String(req.body?.text ?? '').trim();
    if (!text) return err(res, 400, 'Сообщение пустое');
    if (text.length > 4000) return err(res, 400, 'Сообщение слишком длинное (максимум 4000 символов)');

    const msg = store.addMessage({ chatId: chat.id, senderId: me.id, text });

    // Доставляем обоим участникам: у отправителя появится сразу,
    // у собеседника — если он сейчас на связи. Флаг «моё» у каждого свой.
    store.emitMessage(chat.id, msg);

    return res.json({
      ok: true,
      message: {
        id: msg.id,
        chatId: msg.chatId,
        text: msg.text,
        at: msg.at,
        mine: true,
        read: false,
      },
    });
  });

  /** POST /api/chats/:id/read — отметить прочитанным. */
  app.post('/api/chats/:id/read', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const chat = store.getChat(req.params.id);
    if (!chat) return err(res, 404, 'Чат не найден');
    if (!chat.members.includes(me.id)) return err(res, 403, 'Это не ваш чат');

    const fresh = store.markRead(chat.id, me.id);
    // Сообщаем собеседнику, что прочитано — у него появятся две галочки.
    store.emitRead(chat.id, me.id);

    return res.json({ ok: true, fresh });
  });

  /**
   * GET /api/contacts/search?q=номер
   * Ищет зарегистрированных пользователей по номеру — чтобы не гадать.
   */
  app.get('/api/contacts/search', (req, res) => {
    const me = session(req);
    if (!me) return err(res, 401, 'Сессия истекла. Войдите заново.');

    const url = new URL(req.url, 'http://x');
    const q = (url.searchParams.get('q') || '').replace(/\D/g, '');
    if (!q) return res.json({ ok: true, results: [] });

    // Номер могли ввести без кода страны — ищем по последним цифрам.
    const results = store
      .listUsers()
      .filter((u) => u.id !== me.id && u.phone.replace(/\D/g, '').endsWith(q))
      .slice(0, 20)
      .map((u) => ({
        ...publicUser(u),
        lastSeenAt: u.lastSeenAt || null,
        online: store.isOnline ? store.isOnline(u.id) : false,
      }));

    return res.json({ ok: true, results });
  });
}