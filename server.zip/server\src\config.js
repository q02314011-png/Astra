import { readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '..');

function applyDotEnv(file) {
  if (!existsSync(file)) return false;
  for (const raw of readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = val;
  }
  return true;
}

/**
 * Файлы .env по убыванию приоритета.
 *
 * ВАЖНО: пользовательские переменные идут первыми и потому не перезаписываются
 * (applyDotEnv уважает уже установленные env). Это позволяет настройкам
 * пользователя в %APPDATA% перекрыть дефолты из папки установки — иначе
 * записать ключ SMS-провайдера в Program Files не получилось бы.
 */
function loadDotEnv() {
  const files = [];
  if (process.env.ASTRA_ENV_FILE) files.push(process.env.ASTRA_ENV_FILE);
  if (process.env.ASTRA_DATA_DIR) files.push(resolve(process.env.ASTRA_DATA_DIR, '.env'));
  files.push(resolve(root, '.env'));
  files.push(resolve(process.cwd(), '.env'));
  for (const f of files) applyDotEnv(f);
}
loadDotEnv();

const int = (v, def) => {
  const n = Number.parseInt(v ?? '', 10);
  return Number.isFinite(n) ? n : def;
};

const bool = (v, def = false) => {
  if (v === undefined || v === '') return def;
  return ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
};

export const config = {
  port: int(process.env.PORT, 4000),
  host: process.env.HOST || '0.0.0.0',

  // astra | code
  appName: process.env.APP_NAME || 'Astra',

  // dev  — код возвращается в ответе (без реальных SMS, бесплатно)
  // real — код отправляется через SMS-провайдера
  smsMode: (process.env.SMS_MODE || 'dev').toLowerCase(),
  smsProvider: (process.env.SMS_PROVIDER || 'dev').toLowerCase(),

  // 5sim
  fivesimKey: process.env.FIVESIM_API_KEY || '',
  fivesimCountry: process.env.FIVESIM_COUNTRY || 'any',
  fivesimOperator: process.env.FIVESIM_OPERATOR || 'any',

  // SMS-Activate
  smsActivateKey: process.env.SMS_ACTIVATE_API_KEY || '',

  // Twilio
  twilioSid: process.env.TWILIO_ACCOUNT_SID || '',
  twilioToken: process.env.TWILIO_AUTH_TOKEN || '',
  twilioFrom: process.env.TWILIO_FROM_NUMBER || '',

  codeLength: int(process.env.CODE_LENGTH, 5),
  codeTtlSec: int(process.env.CODE_TTL_SEC, 180),
  resendAfterSec: int(process.env.RESEND_AFTER_SEC, 60),
  maxAttempts: int(process.env.MAX_ATTEMPTS, 5),
  maxSmsPerHour: int(process.env.MAX_SMS_PER_HOUR, 8),
  maxSmsPerDay: int(process.env.MAX_SMS_PER_DAY, 30),
  sessionTtlDays: int(process.env.SESSION_TTL_DAYS, 30),

  // Отдавать код в ответе только в dev-режиме
  exposeCode: bool(process.env.EXPOSE_CODE, process.env.SMS_MODE !== 'real'),
};

export const isDevSms = () => config.smsMode !== 'real';
