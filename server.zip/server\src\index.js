// Точка входа для обычного запуска: node src/index.js
import { startServer, bannerLines } from './app.js';
import { config } from './config.js';

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));

let started;
try {
  started = await startServer();
} catch (e) {
  // Ошибка listen() — показываем, что делать, вместо стектрейса Node.
  if (e?.code === 'EADDRINUSE') {
    console.error(`\n  Порт ${config.port} уже занят.`);
    console.error(`  Возможно, сервер Astra уже запущен — проверь:`);
    console.error(`    http://127.0.0.1:${config.port}/api/health`);
    console.error(`  Или запусти на другом порту: PORT=4100 node src/index.js\n`);
  } else {
    console.error('[fatal]', e?.message || e);
  }
  process.exit(1);
}

const { server, port, urls } = started;
console.log(bannerLines({ port, urls }).join('\n'));

const shutdown = () => {
  console.log('\n  сервер останавливается...');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

server.on('error', (e) => {
  console.error('[server error]', e?.message || e);
  process.exit(1);
});
