/**
 * 5sim — api.5sim.net
 * Документация: https://5sim.net/en/api
 *
 * Нужен ключ: https://5sim.net/en/profile (пополнение от ~$1, есть тестовые кредиты)
 */
import { config } from '../config.js';

export const name = 'fivesim';

const API = 'https://api.5sim.net/v1';

/** Код ISO-3166(alpha-2) -> код страны 5sim */
const COUNTRY = {
  ru: 'ru', ua: 'ua', by: 'by', kz: 'kz', uz: 'uz', kg: 'kg',
  tj: 'tj', tm: 'tm', am: 'am', az: 'az', ge: 'ge', md: 'md',
  pl: 'pl', de: 'de', us: 'us', gb: 'gb', tr: 'tr', fr: 'fr',
  es: 'es', it: 'it', br: 'br', in: 'in',
};

const headers = () => ({
  Authorization: `Bearer ${config.fivesimKey}`,
  Accept: 'application/json',
});

export async function send({ phone, countryIso, text }) {
  if (!config.fivesimKey) return { ok: false, error: 'FIVESIM_API_KEY не задан' };

  const country = COUNTRY[countryIso] || config.fivesimCountry;
  const operator = config.fivesimOperator;

  let buy;
  try {
    const res = await fetch(
      `${API}/user/buy/activation/${encodeURIComponent(country)}/${encodeURIComponent(operator)}`,
      { method: 'POST', headers: headers() },
    );
    buy = await res.json();
  } catch (e) {
    return { ok: false, error: `сеть недоступна: ${e.message}` };
  }

  const activationId = buy?.id;
  if (!activationId) {
    return { ok: false, error: buy?.message || 'не удалось купить номер (нет свободных операторов?)' };
  }

  const number = String(buy.phone || '').replace(/^\+/, '');
  if (number && !phone.replace(/\D/g, '').endsWith(number)) {
    // номер отличается — всё равно продолжим, но предупредим
    console.warn(`[fivesim] номер ${number} != запрошенный ${phone}`);
  }

  // Ждём SMS до 90 секунд
  const deadline = Date.now() + 90_000;
  while (Date.now() < deadline) {
    await sleep(4000);
    try {
      const r = await fetch(`${API}/user/check/activation/${activationId}`, { headers: headers() });
      const st = await r.json();
      const code = extractCode(st?.sms?.[0]?.text || st?.text || '');
      if (code) {
        return {
          ok: true,
          code,
          externalId: String(activationId),
          provider: 'fivesim',
          detail: `5sim, оператор ${st?.operator || operator}`,
        };
      }
      if (st?.status === 'TIMEOUT' || st?.status === 'CANCEL') {
        return { ok: false, error: `5sim: ${st.status} — SMS не пришло` };
      }
    } catch {
      /* повторяем */
    }
  }
  return { ok: false, error: '5sim: таймаут ожидания SMS (90с)' };
}

export async function check() {
  if (!config.fivesimKey) return { ok: false, balance: null, detail: 'ключ не задан' };
  try {
    const r = await fetch(`${API}/user/profile`, { headers: headers() });
    const p = await r.json();
    return { ok: r.ok, balance: p?.balance ?? null, detail: p?.username || '' };
  } catch (e) {
    return { ok: false, balance: null, detail: e.message };
  }
}

function extractCode(text) {
  if (!text) return null;
  const m = String(text).match(/\b(\d{4,8})\b/);
  return m ? m[1] : null;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
