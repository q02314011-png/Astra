/**
 * Полный тест чатов: два пользователя, переписка, realtime, прочитано.
 * Запуск: node src/selftest-chat.js
 */
const base = process.env.ASTRA_TEST_BASE || 'http://127.0.0.1:4000';

let pass = 0;
let fail = 0;
const ok = (cond, label, extra = '') => {
  if (cond) {
    pass++;
    console.log(`  ok   ${label}`);
  } else {
    fail++;
    console.log(`  FAIL ${label} ${extra}`);
  }
};

async function call(path, { method = 'GET', token, body } = {}) {
  const r = await fetch(base + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {}
  return { status: r.status, json, text };
}

/** Вход по номеру в dev-режиме: код приходит сразу. */
async function signIn(phone, name) {
  const req = await call('/api/auth/request-code', {
    method: 'POST',
    body: { phone, country: 'ru', deviceId: 'test' },
  });
  const code = req.json?.devCode;
  if (!code) throw new Error(`нет devCode для ${phone}: ${req.text}`);
  const ver = await call('/api/auth/verify-code', {
    method: 'POST',
    body: { phone: req.json.phoneHint, code, name },
  });
  if (!ver.json?.token) throw new Error(`вход не удался: ${ver.text}`);
  return ver.json;
}

console.log('1. два пользователя входят');
const alice = await signIn('9000000001', 'Алиса');
const bob = await signIn('9000000002', 'Борис');
ok(Boolean(alice.token), 'Алиса получила токен');
ok(Boolean(bob.token), 'Борис получил токен');
ok(alice.user.phone !== bob.user.phone, 'номера различаются');

console.log('\n2. чат по номеру');
const found = await call('/api/contacts/search?q=9000000002', { token: alice.token });
ok(found.json?.results?.length === 1, 'Борис находится в поиске по номеру');
ok(found.json?.results?.[0]?.name === 'Борис', 'в поиске верное имя');

const chatRes = await call('/api/chats', {
  method: 'POST',
  token: alice.token,
  body: { phone: bob.user.phone, country: 'ru' },
});
ok(chatRes.json?.ok === true, 'чат создан', chatRes.text);
const chatId = chatRes.json?.chat?.id;
ok(Boolean(chatId), 'id чата получен');
ok(chatRes.json?.chat?.peer?.name === 'Борис', 'собеседник — Борис');

console.log('\n3. повторное создание не плодит дубли');
const again = await call('/api/chats', {
  method: 'POST',
  token: alice.token,
  body: { phone: bob.user.phone, country: 'ru' },
});
ok(again.json?.chat?.id === chatId, 'тот же чат вернулся');

console.log('\n4. чат с незарегистрированным номером');
const stranger = await call('/api/chats', {
  method: 'POST',
  token: alice.token,
  body: { phone: '9009999999', country: 'ru' },
});
ok(stranger.status === 404, '404 для чужого номера', String(stranger.status));
ok(/не зарегистрирован/.test(stranger.json?.error || ''), 'понятное сообщение');

console.log('\n5. чат с самим собой запрещён');
const self = await call('/api/chats', {
  method: 'POST',
  token: alice.token,
  body: { phone: alice.user.phone, country: 'ru' },
});
ok(self.status === 400, '400 для себя', String(self.status));

console.log('\n6. сообщения');
const m1 = await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: alice.token,
  body: { text: 'Привет, Борис!' },
});
ok(m1.json?.ok === true, 'Алиса отправила сообщение');
ok(m1.json?.message?.mine === true, 'помечено как своё');

const m2 = await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: bob.token,
  body: { text: 'Привет! Как дела?' },
});
ok(m2.json?.ok === true, 'Борис ответил');

const hist = await call(`/api/chats/${chatId}/messages`, { token: alice.token });
ok(hist.json?.messages?.length === 2, 'в истории 2 сообщения', String(hist.json?.messages?.length));
ok(hist.json?.messages?.[0]?.mine === true, 'первое — своё');
ok(hist.json?.messages?.[1]?.mine === false, 'второе — чужое');

console.log('\n7. список чатов и непрочитанные');
const listA = await call('/api/chats', { token: alice.token });
ok(listA.json?.chats?.length === 1, 'у Алисы 1 чат');
ok(listA.json?.chats?.[0]?.unread === 1, '1 непрочитанное');
ok(listA.json?.chats?.[0]?.lastMessage?.text === 'Привет! Как дела?', 'последнее сообщение видно');
ok(listA.json?.unreadTotal === 1, 'счётчик непрочитанных = 1');

console.log('\n8. пустое и слишком длинное сообщение');
const empty = await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: alice.token,
  body: { text: '   ' },
});
ok(empty.status === 400, 'пустое отклонено', String(empty.status));

const huge = await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: alice.token,
  body: { text: 'я'.repeat(4001) },
});
ok(huge.status === 400, 'слишком длинное отклонено', String(huge.status));

console.log('\n9. чужим чатом пользоваться нельзя');
const carol = await signIn('9000000003', 'Клара');
const peek = await call(`/api/chats/${chatId}/messages`, { token: carol.token });
ok(peek.status === 403, 'чтение чужого чата — 403', String(peek.status));
const push = await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: carol.token,
  body: { text: 'подслушиваю' },
});
ok(push.status === 403, 'запись в чужой чат — 403', String(push.status));

console.log('\n10. без токена — 401');
const anon = await call('/api/chats');
ok(anon.status === 401, 'список чатов без токена — 401', String(anon.status));

console.log('\n11. отметка «прочитано»');
// Борис открыл чат и прочитал сообщение Алисы.
const read = await call(`/api/chats/${chatId}/read`, { method: 'POST', token: bob.token });
ok(read.json?.ok === true, 'Борис отметил прочитанным');
ok(read.json?.fresh === 1, 'одно новое прочитанное');

// Непрочитанные считаются отдельно для каждого: Алиса чат не открывала,
// поэтому её собственное непрочитанное от сообщения Бориса остаётся.
const listB = await call('/api/chats', { token: bob.token });
ok(listB.json?.chats?.[0]?.unread === 0, 'у Бориса непрочитанных нет');

const listA2 = await call('/api/chats', { token: alice.token });
ok(listA2.json?.chats?.[0]?.unread === 1, 'у Алисы своё непрочитанное на месте');

// Алиса открывает чат — счётчик обнуляется у неё.
await call(`/api/chats/${chatId}/read`, { method: 'POST', token: alice.token });
const listA3 = await call('/api/chats', { token: alice.token });
ok(listA3.json?.chats?.[0]?.unread === 0, 'после прочтения у Алисы чисто');
ok(listA3.json?.unreadTotal === 0, 'общий счётчик обнулился');

console.log('\n12. realtime: событие приходит в поток');
const controller = new AbortController();
const streamRes = await fetch(`${base}/api/events?token=${alice.token}`, {
  signal: controller.signal,
});
ok(streamRes.ok, 'поток событий открылся', String(streamRes.status));
const reader = streamRes.body.getReader();
const decoder = new TextDecoder();

const readOne = async (timeoutMs = 6000) => {
  const t = Date.now();
  let buf = '';
  while (Date.now() - t < timeoutMs) {
    const chunk = await reader.read();
    if (chunk.done) break;
    buf += decoder.decode(chunk.value, { stream: true });
    const line = buf.split('\n').find((l) => l.trim().startsWith('{'));
    if (line) return JSON.parse(line);
  }
  return null;
};

const hello = await readOne();
ok(hello?.type === 'hello', 'первый кадр — hello', JSON.stringify(hello));

// Борис пишет — Алиса должна получить это в своём потоке
await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: bob.token,
  body: { text: 'сообщение в реальном времени' },
});
const evt = await readOne(8000);
ok(evt?.type === 'message', 'пришло событие message', JSON.stringify(evt));
ok(evt?.message?.text === 'сообщение в реальном времени', 'текст события верный');
// Алиса — получатель, поэтому её копия события не должна помечаться как своя.
ok(evt?.message?.mine === false, 'у получателя сообщение чужое', JSON.stringify(evt?.message?.mine));

// У отправителя та же доставка должна выглядеть как своё сообщение.
const senderCtrl = new AbortController();
const senderStream = await fetch(`${base}/api/events?token=${bob.token}`, {
  signal: senderCtrl.signal,
});
const senderReader = senderStream.body.getReader();
const senderRead = async (timeoutMs = 6000) => {
  const t = Date.now();
  let acc = '';
  while (Date.now() - t < timeoutMs) {
    const chunk = await senderReader.read();
    if (chunk.done) break;
    acc += decoder.decode(chunk.value, { stream: true });
    const line = acc.split('\n').find((l) => l.trim().startsWith('{'));
    if (line) return JSON.parse(line);
  }
  return null;
};
await senderRead(); // hello
await call(`/api/chats/${chatId}/messages`, {
  method: 'POST',
  token: bob.token,
  body: { text: 'моё собственное' },
});
const mineEvt = await senderRead(8000);
ok(mineEvt?.message?.mine === true, 'у отправителя сообщение своё', JSON.stringify(mineEvt?.message?.mine));
senderCtrl.abort();
await senderReader.cancel().catch(() => {});

controller.abort();
await reader.cancel().catch(() => {});

console.log('\n13. правда на чужом токене');
const badStream = await call('/api/events?token=мусор');
ok(badStream.status === 401, 'поток с чужим токеном — 401', String(badStream.status));

console.log('\n14. параметры маршрута');
const bad = await call('/api/chats/не-существует/messages', { token: alice.token });
ok(bad.status === 404, 'несуществующий чат — 404', String(bad.status));

console.log(`\nИТОГ: ${pass} ok, ${fail} FAIL`);
process.exit(fail ? 1 : 0);