/**
 * Режим DEV — реальных SMS нет, код возвращается в ответе API.
 * Нужен, чтобы целиком проверить сценарий входа без денег и без SIM.
 * Включён по умолчанию (SMS_MODE=dev в .env).
 */
import { randomInt } from 'node:crypto';

export const name = 'dev';

export async function send({ phone, text }) {
  const code = String(randomInt(10000, 99999));
  return {
    ok: true,
    code, // отдаём наружу — только в dev-режиме
    externalId: `dev-${Date.now()}`,
    provider: 'dev',
    detail: 'код показан в приложении (dev-режим)',
  };
}

export async function check() {
  return { ok: true, balance: null, detail: 'dev-режим: реальные SMS не отправляются' };
}
