package com.astra.messenger;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.util.HashMap;
import java.util.Map;

/**
 * Astra — нативная оболочка Android.
 *
 * Интерфейс собран как веб-приложение (app/dist) и лежит в assets/public.
 * Нативный слой здесь минимальный: нужен только WebView, разрешение на http
 * (сервер Astra в локальной сети) и передача флага платформы в JS.
 */
public class MainActivity extends android.app.Activity {

    private WebView web;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setBackgroundColor(Color.parseColor("#0F0F0F"));

        web = new WebView(this);
        web.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.setBackgroundColor(Color.parseColor("#0F0F0F"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        // Приложение живёт в assets/, поэтому нужно разрешить доступ к file://
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Внешние ссылки (Telegram, почта) открываем в системном браузере
                if (url != null && !url.startsWith("file://") && !url.startsWith("http://localhost")
                        && !url.startsWith("https://localhost")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) {
                    }
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                injectPlatformFlag(view);
            }
        });

        root.addView(web);
        setContentView(root);

        web.loadUrl("file:///android_asset/public/index.html");
        injectPlatformFlag(web);
    }

    /** Сообщаем фронтенду, что мы в нативной Android-оболочке. */
    private void injectPlatformFlag(WebView view) {
        try {
            view.evaluateJavascript(
                    "window.__ASTRA_ANDROID__ = true;"
                            + "window.AstraNative = window.AstraNative || {};"
                            + "window.AstraNative.platform = 'android';",
                    null);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
