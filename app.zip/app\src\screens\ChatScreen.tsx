import { useEffect, useRef, useState } from 'react';
import { api, ApiError, type Message, type User } from '../api';
import { Avatar } from '../components/Avatar';
import { Banner } from '../components/Banner';
import { onRealtime } from '../realtime';

function clock(at: number): string {
  return new Date(at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

function dayLabel(at: number): string {
  const d = new Date(at);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return 'Сегодня';
  const y = new Date(today);
  y.setDate(today.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'Вчера';
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });
}

export function ChatScreen({
  chatId,
  onBack,
  onToast,
}: {
  chatId: string;
  onBack: () => void;
  onToast: (m: string) => void;
}) {
  const [peer, setPeer] = useState<User | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const scroller = useRef<HTMLDivElement>(null);
  const atBottom = useRef(true);

  /** Прокрутка вниз только если пользователь и так внизу — иначе не мешаем читать. */
  const scrollToBottom = (smooth = false) => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  };

  const loadAll = async () => {
    setBusy(true);
    try {
      const [chatRes, msgRes] = await Promise.all([
        api.chat(chatId),
        api.messages(chatId),
      ]);
      setPeer(chatRes.chat.peer);
      setMessages(msgRes.messages);
      setHasMore(msgRes.hasMore);
      setError('');
      requestAnimationFrame(() => scrollToBottom());
      // Открытый чат сразу считаем прочитанным.
      if (chatRes.chat.unread > 0) {
        api.markRead(chatId).catch(() => {});
      }
    } catch (e) {
      setError((e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    loadAll();
  }, [chatId]);

  // Входящие события по этому чату.
  useEffect(() => {
    return onRealtime((evt) => {
      if (evt.type === 'message' && evt.chatId === chatId) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === evt.message.id)) return prev;
          const next = [...prev, evt.message];
          if (atBottom.current) requestAnimationFrame(() => scrollToBottom(true));
          else {
            onToast(`Новое сообщение от ${peer?.name || 'контакта'}`);
          }
          // Мы в чате — сразу подтверждаем прочтение.
          if (!evt.message.mine) api.markRead(chatId).catch(() => {});
          return next;
        });
      }
      if (evt.type === 'read' && evt.chatId === chatId) {
        setMessages((prev) => prev.map((m) => (m.mine ? { ...m, read: true } : m)));
      }
    });
  }, [chatId, peer?.name]);

  const onScroll = () => {
    const el = scroller.current;
    if (!el) return;
    atBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 60;

    // Дошли до верха — подгружаем историю.
    if (el.scrollTop < 40 && hasMore && !loadingMore) {
      setLoadingMore(true);
      const first = messages[0];
      api
        .messages(chatId, first?.at)
        .then((res) => {
          if (!res.messages.length) {
            setHasMore(false);
            return;
          }
          const prevHeight = el.scrollHeight;
          setMessages((prev) => [...res.messages, ...prev]);
          setHasMore(res.hasMore);
          requestAnimationFrame(() => {
            el.scrollTop = el.scrollHeight - prevHeight;
          });
        })
        .catch(() => {})
        .finally(() => setLoadingMore(false));
    }
  };

  const send = async () => {
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    setError('');
    try {
      const res = await api.sendMessage(chatId, body);
      setMessages((prev) => (prev.some((m) => m.id === res.message.id) ? prev : [...prev, res.message]));
      setText('');
      atBottom.current = true;
      requestAnimationFrame(() => scrollToBottom(true));
    } catch (e) {
      setError((e as ApiError).message);
    } finally {
      setSending(false);
    }
  };

  // Разделитель даты, когда меняется день.
  let lastDay = '';

  return (
    <>
      <div className="header">
        <button className="header__back" onClick={onBack}>
          ‹
        </button>
        <div className="chat-head">
          <Avatar name={peer?.name || '?'} color={peer?.avatarColor} size="sm" />
          <div>
            <div className="chat-head__name">{peer?.name || 'Переписка'}</div>
            <div className="chat-head__sub mono">
              {peer?.phone ? `+${peer.phone.replace(/^\+/, '')}` : ''}
            </div>
          </div>
        </div>
      </div>

      <div className="chat" ref={scroller} onScroll={onScroll}>
        {busy ? (
          <div className="empty">
            <span className="spinner" />
          </div>
        ) : (
          <>
            {loadingMore && (
              <div className="chat__load">
                <span className="spinner" />
              </div>
            )}
            {!hasMore && messages.length > 0 && (
              <div className="chat__start">Сообщения защищены сквозным каналом Astra</div>
            )}
            {messages.length === 0 && (
              <div className="chat__empty">
                Сообщений пока нет. Напиши первым — сообщение доставится сразу.
              </div>
            )}
            {messages.map((m) => {
              const day = dayLabel(m.at);
              const showDay = day !== lastDay;
              lastDay = day;
              return (
                <div key={m.id}>
                  {showDay && <div className="chat__day">{day}</div>}
                  <div className={`bubble${m.mine ? ' bubble--mine' : ''}`}>
                    <div className="bubble__text">{m.text}</div>
                    <div className="bubble__meta">
                      {clock(m.at)}
                      {m.mine && <span className="bubble__ticks">{m.read ? '✓✓' : '✓'}</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </>
        )}
      </div>

      {error && (
        <div className="chat__error">
          <Banner kind="error">{error}</Banner>
        </div>
      )}

      <div className="composer">
        <textarea
          className="composer__input"
          rows={1}
          placeholder="Сообщение…"
          value={text}
          maxLength={4000}
          onChange={(e) => {
            setText(e.target.value);
            e.target.style.height = 'auto';
            e.target.style.height = Math.min(120, e.target.scrollHeight) + 'px';
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
        />
        <button className="composer__send" onClick={send} disabled={!text.trim() || sending}>
          {sending ? '…' : '➤'}
        </button>
      </div>
    </>
  );
}