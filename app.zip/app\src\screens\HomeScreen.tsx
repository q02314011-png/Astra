import { useEffect, useState } from 'react';
import { api, getServerUrl, isLocalMode, type User } from '../api';
import { Avatar } from '../components/Avatar';
import { Banner } from '../components/Banner';
import { onRealtime } from '../realtime';

export function HomeScreen({
  user,
  offline: offlineProp = false,
  onOpenProfile,
  onOpenSettings,
  onOpenChats,
  onToast,
  onLogout,
}: {
  user: User;
  /** Профиль показан из кэша: сервер не отвечает или включён автономный режим. */
  offline?: boolean;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onOpenChats: () => void;
  onToast: (m: string) => void;
  onLogout: () => void;
}) {
  const [health, setHealth] = useState<any>(null);
  const [offline, setOffline] = useState(offlineProp);
  const [unread, setUnread] = useState(0);
  const [chatCount, setChatCount] = useState(0);
  const autonomous = isLocalMode();

  /** Счётчик непрочитанных и число диалогов для главного экрана. */
  const loadChats = async () => {
    if (autonomous) return;
    try {
      const res = await api.chats();
      setUnread(res.unreadTotal || 0);
      setChatCount(res.chats?.length || 0);
    } catch {
      /* сервер недоступен — счётчик не критичен */
    }
  };

  useEffect(() => {
    loadChats();
  }, [autonomous]);

  // Новое сообщение сразу отражается на главном экране.
  useEffect(() => {
    if (autonomous) return;
    return onRealtime((evt) => {
      if (evt.type === 'message' && !evt.message.mine) {
        setUnread((u) => u + 1);
        setChatCount((c) => Math.max(c, 1));
      } else if (evt.type === 'message') {
        setChatCount((c) => Math.max(c, 1));
      }
    });
  }, [autonomous]);

  useEffect(() => {
    if (autonomous) return;
    let alive = true;
    const check = async () => {
      try {
        const h = await api.health();
        if (!alive) return;
        setHealth(h);
        setOffline(false);
      } catch {
        if (alive) setOffline(true);
      }
    };
    check();
    const t = setInterval(check, 15000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [autonomous]);

  return (
    <>
      <div className="header">
        <div className="header__title">Astra</div>
        <button className="header__action" onClick={onOpenSettings}>
          Настройки
        </button>
      </div>

      <div className="body">
        {autonomous && (
          <Banner kind="warn">
            Автономный режим: сервер не используется. Вход и профиль работают на
            устройстве, SMS не отправляются, данные ни с кем не синхронизируются.
          </Banner>
        )}

        {!autonomous && offline && (
          <Banner kind="error">
            Нет связи с сервером <span className="mono">{getServerUrl()}</span>. Показан
            сохранённый профиль. Проверь, что сервер запущен, или перейди в настройки —
            там есть автономный режим.
          </Banner>
        )}

        <button className="profile-card" onClick={onOpenProfile} style={{ cursor: 'pointer' }}>
          <Avatar name={user.name} color={user.avatarColor} size="lg" />
          <div className="profile-card__name">{user.name}</div>
          <div className="profile-card__phone mono">+{user.phone.replace(/^\+/, '')}</div>
          <div className="verified">✓ Вход подтверждён по SMS</div>
        </button>

        <div className="section-title">Чаты</div>
        {unread > 0 && (
          <button className="row" onClick={onOpenChats}>
            <div className="row__body">
              <div className="row__title">
                Непрочитанных сообщений: {unread}
              </div>
              <div className="row__sub">нажми, чтобы открыть переписку</div>
            </div>
            <span className="badge">{unread}</span>
            <span className="row__chev">›</span>
          </button>
        )}
        <button className="row" onClick={onOpenChats}>
          <div className="row__body">
            <div className="row__title">Мои диалоги</div>
            <div className="row__sub">
              {autonomous
                ? 'в автономном режиме чатов нет'
                : chatCount > 0
                  ? `диалогов: ${chatCount}`
                  : 'начни переписку по номеру друга'}
            </div>
          </div>
          <span className="row__chev">›</span>
        </button>

        {health && (
          <>
            <div className="divider" />
            <div className="section-title">Состояние сервера</div>
            <div className="row" style={{ cursor: 'default' }}>
              <span className={`status-dot ${offline ? 'status-dot--off' : 'status-dot--on'}`} />
              <div className="row__body">
                <div className="row__title">Соединение</div>
                <div className="row__sub mono">{getServerUrl()}</div>
              </div>
              <span className="row__value">{offline ? 'нет' : 'ок'}</span>
            </div>
            <div className="row" style={{ cursor: 'default' }}>
              <div className="row__body">
                <div className="row__title">Режим SMS</div>
                <div className="row__sub">
                  {health.mode === 'dev'
                    ? 'тестовый — код в приложении, SMS не отправляются'
                    : `реальные SMS через ${health.provider}`}
                </div>
              </div>
              <span className="row__value">{health.mode}</span>
            </div>
            <div className="row" style={{ cursor: 'default' }}>
              <div className="row__body">
                <div className="row__title">Аккаунтов в базе</div>
                <div className="row__sub">всего зарегистрировано</div>
              </div>
              <span className="row__value">{health.stats?.users ?? 0}</span>
            </div>
            {health.providerStatus?.balance != null && (
              <div className="row" style={{ cursor: 'default' }}>
                <div className="row__body">
                  <div className="row__title">Баланс SMS-провайдера</div>
                  <div className="row__sub">{health.providerStatus.detail}</div>
                </div>
                <span className="row__value">{health.providerStatus.balance}</span>
              </div>
            )}
          </>
        )}

        <div className="divider" />
        <button className="row" onClick={onOpenProfile}>
          <div className="row__body">
            <div className="row__title">Изменить имя</div>
            <div className="row__sub">как вас увидят другие</div>
          </div>
          <span className="row__value">{user.name}</span>
          <span className="row__chev">›</span>
        </button>
        <button className="row" onClick={onOpenSettings}>
          <div className="row__body">
            <div className="row__title">Сервер и вход</div>
            <div className="row__sub">адрес сервера, проверка подключения</div>
          </div>
          <span className="row__chev">›</span>
        </button>
        <button
          className="row"
          onClick={() => {
            navigator.clipboard?.writeText(user.id).then(
              () => onToast('ID скопирован'),
              () => onToast(user.id),
            );
          }}
        >
          <div className="row__body">
            <div className="row__title">Мой ID</div>
            <div className="row__sub mono">{user.id.slice(0, 18)}…</div>
          </div>
          <span className="row__chev">›</span>
        </button>
        <button className="btn btn--danger" style={{ marginTop: 18 }} onClick={onLogout}>
          Выйти из аккаунта
        </button>
      </div>
    </>
  );
}
