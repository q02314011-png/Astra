export function Avatar({
  name,
  color = '#3390ec',
  size = 'md',
}: {
  name: string;
  color?: string;
  size?: 'sm' | 'md' | 'lg';
}) {
  const initials = (name || '?')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();

  const cls = size === 'md' ? 'avatar' : `avatar avatar--${size}`;
  return (
    <div className={cls} style={{ background: color }}>
      {initials}
    </div>
  );
}
