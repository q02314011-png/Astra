import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.astra.messenger',
  appName: 'Astra',
  webDir: 'dist',
  android: {
    // Разрешаем http:// — сервер Astra в тесте живёт в локальной сети
    allowMixedContent: true,
  },
  server: {
    androidScheme: 'http',
    cleartext: true,
  },
};

export default config;
