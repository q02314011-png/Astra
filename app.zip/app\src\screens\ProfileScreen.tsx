import { useState } from 'react';
import { api, ApiError, getServerUrl, setServerUrl, type User } from '../api';
import { Banner } from '../components/Banner';
import { Avatar } from '../components/Avatar';

export function ProfileScreen({
  user,
  onBack,
  onSaved,
  onToast,
}: {
  user: User;
  onBack: () => void;
  onSaved: (u: User) => void;
  onToast: (m: string) => void;
}) {
  const [name, setName] = useState(user.name);
  const [bio, setBio] = useState(user.bio || '');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const save = async () => {
    setError('');
    if (!name.trim()) {
      setError('Имя не может быть пустым');
      return;
    }
    setBusy(true);
    try {
      const res = await api.updateMe({ name: name.trim(), bio: bio.trim() });
      onSaved(res.user);
      onToast('Профиль обновлён');
      onBack();
    } catch (e) {
      setError((e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="header">
        <button className="header__back" onClick={onBack}>
          ‹
        </button>
        <div className="header__title">Изменить профиль</div>
      </div>
      <div className="body">
        <div style={{ display: 'flex', justifyContent: 'center', margin: '10px 0 24px' }}>
          <Avatar name={name || '?'} color={user.avatarColor} size="lg" />
        </div>

        {error && <Banner kind="error">{error}</Banner>}

        <div className="field">
          <label className="field__label">Имя</label>
          <input
            className="input"
            value={name}
            maxLength={64}
            onChange={(e) => setName(e.target.value)}
            placeholder="Как вас зовут"
          />
        </div>
        <div className="field">
          <label className="field__label">О себе</label>
          <input
            className="input"
            value={bio}
            maxLength={140}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Пара слов о себе"
          />
        </div>
        <div className="field">
          <label className="field__label">Номер телефона</label>
          <input className="input mono" value={'+' + user.phone.replace(/^\+/, '')} disabled />
        </div>

        <button className="btn" onClick={save} disabled={busy}>
          {busy ? 'Сохраняем…' : 'Сохранить'}
        </button>
      </div>
    </>
  );
}
