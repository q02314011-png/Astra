/**
 * Работа с адресом сервера.
 *
 * Задача модуля — не дать пользователю упереться в «ошибка http://127.0.0.01:4000».
 * Здесь три вещи:
 *   1. normalizeServerUrl — чинит очевидные опечатки в адресе (127.0.0.01 → 127.0.0.1);
 *   2. discoverServers    — перебирает вероятные адреса и находит живой сервер;
 *   3. explainConnectionError — превращает техническую ошибку fetch в понятный текст.
 */

export const DEFAULT_PORT = 4000;

export type NormalizeResult = {
  url: string;
  /** Была ли в адресе опечатка, которую мы исправили. */
  fixed?: boolean;
  /** Что именно исправили — показываем пользователю. */
  note?: string;
  /** Именно опечатка (а не дописанная схема/порт) — стоит подсветить пользователю. */
  typo?: boolean;
  /** Адрес не похож на нормальный, пробовать бессмысленно. */
  invalid?: boolean;
};

function cleanIpv4(host: string): { host: string; note?: string } {
  // 127.0.0.01 -> 127.0.0.1 (ведущие нули), 127.0.0.1. -> 127.0.0.1 (хвостовая точка)
  let h = host;
  let note: string | undefined;

  if (/^\d+(\.\d+)*\.?$/.test(h)) {
    if (h.endsWith('.')) {
      h = h.slice(0, -1);
      note = 'убрана лишняя точка в конце адреса';
    }
    const parts = h.split('.');
    const normalized = parts.map((p) => {
      const n = Number.parseInt(p, 10);
      return String(Number.isFinite(n) ? n : p);
    });
    if (normalized.join('.') !== parts.join('.')) {
      note = `«${host}» исправлено на «${normalized.join('.')}»`;
    }
    h = normalized.join('.');
  }

  return { host: h, note };
}

/** Проверяет, что хост — либо домен, либо корректный IPv4. Иначе адрес невалиден. */
function invalidHostReason(host: string): string | null {
  if (!host) return 'В адресе нет имени хоста';

  if (/^\d+(\.\d+){1,3}$/.test(host)) {
    const octets = host.split('.');
    const bad = octets.find((p) => Number.parseInt(p, 10) > 255);
    if (bad) return `часть «${bad}» больше 255 — такого адреса не бывает`;
    if (octets.length !== 4) return 'IPv4-адрес должен содержать 4 части';
    return null;
  }

  // Домен: только латиница, цифры, дефисы и точки. Плюс punycode для кириллицы.
  if (!/^(xn--)?[a-z0-9-]+(\.[a-z0-9-]+)*$/i.test(host)) {
    return `«${host}» не похоже на домен или IP-адрес`;
  }
  return null;
}

/**
 * Приводит то, что ввёл пользователь, к виду http://host:port
 * и по возможности чинит опечатки.
 */
export function normalizeServerUrl(input: string, defaultPort = DEFAULT_PORT): NormalizeResult {
  const original = String(input || '').trim();
  if (!original) {
    return { url: '', invalid: true, note: 'Адрес не указан' };
  }

  // Домен не может содержать кириллицу в том виде, в каком её набрали.
  if (/[^\x00-\x7F]/.test(original.replace(/\s+/g, ''))) {
    return { url: original, invalid: true, note: 'В адресе есть нелатинские символы' };
  }

  let s = original.replace(/\s+/g, '');

  // Схема уже была написана, но с опечаткой (htp://, htps://) — запомним это.
  let schemeWasTyped = false;

  // http:/127.0.0.1 -> http://127.0.0.1
  s = s.replace(/^(https?):\/(?!\/)/, '$1://');
  if (!/^https?:\/\//i.test(s)) {
    // Опечатка в схеме: htp://, htps://, hhttp://, а также «://» без схемы.
    // Отличаем по близости к http/https; всё остальное считаем именем хоста.
    const m = s.match(/^([a-z]{2,10})[:/]{1,2}(.*)$/i);
    const scheme = m?.[1]?.toLowerCase() ?? '';
    const rest = m?.[2] ?? '';
    const dHttp = editDistance(scheme, 'http');
    const dHttps = editDistance(scheme, 'https');
    if (rest && Math.min(dHttp, dHttps) <= 2) {
      schemeWasTyped = true;
      s = (dHttps < dHttp ? 'https://' : 'http://') + rest.replace(/^\/+/, '');
    } else {
      // Схемы нет вообще: отбрасываем ведущие «://» и слэши, но не трогаем
      // двоеточие в «host:port».
      s = 'http://' + s.replace(/^[:/]+/, '');
    }
  }

  // WHATWG-парсер сам отвергает 999.1.1.1, поэтому проверяем октеты заранее —
  // так сообщение об ошибке понятнее.
  const rawHost = s
    .replace(/^[a-z][a-z0-9+.-]*:\/\//i, '')
    .split(/[/?#]/)[0]
    .replace(/:\d+$/, '');
  if (/^\d+(\.\d+){1,3}$/.test(rawHost)) {
    const bad = rawHost.split('.').find((p) => Number.parseInt(p, 10) > 255);
    if (bad) {
      return {
        url: original,
        invalid: true,
        note: `часть «${bad}» больше 255 — такого адреса не бывает`,
      };
    }
    if (rawHost.split('.').length !== 4) {
      return { url: original, invalid: true, note: 'IPv4-адрес должен содержать 4 части' };
    }
  }

  let url: URL;
  try {
    url = new URL(s);
  } catch {
    return { url: original, invalid: true, note: `Не похоже на адрес: «${original}»` };
  }

  let host = url.hostname;
  const { host: fixedHost, note: hostNote } = cleanIpv4(host);
  host = fixedHost;

  const reason = invalidHostReason(host);
  if (reason) return { url: original, invalid: true, note: reason };

  const port = url.port || String(defaultPort);
  const scheme = url.protocol.replace(':', '').toLowerCase();
  const fixed = `${scheme}://${host}:${port}`;

  // Различаем две вещи:
  //  fixed — текст изменился (дописали схему, порт);
  //  typo  — мы починили именно опечатку, её стоит показать пользователю.
  // Без этого разделения ввод «astra.example.com» выглядел бы как ошибка.
  const addedScheme = /^https?:\/\//i.test(original) ? '' : scheme;
  const addedPort = original.replace(/^https?:\/\//i, '').includes(':') ? '' : `:${port}`;
  const typo = Boolean(hostNote) || schemeWasTyped;
  const changed = fixed !== original && fixed !== `${original}/`;

  return {
    url: fixed,
    fixed: changed,
    typo,
    note: changed
      ? hostNote || `дописано: ${addedScheme}${addedPort || ''}`.trim()
      : undefined,
  };
}

/** Вероятные адреса сервера на этой машине / в этой сети. */
export function candidateUrls(port = DEFAULT_PORT): string[] {
  const list = [
    `http://127.0.0.1:${port}`,
    `http://localhost:${port}`,
    // Android-эмулятор: хост с точки зрения гостевой VM
    `http://10.0.2.2:${port}`,
  ];
  return list;
}

export type ProbeResult = {
  url: string;
  ok: boolean;
  ms: number;
  error?: string;
  health?: {
    app?: string;
    version?: string;
    mode?: string;
    provider?: string;
    stats?: Record<string, number>;
  };
};

/** Один быстрый запрос /api/health с жёстким таймаутом. */
export async function probeServer(
  base: string,
  timeoutMs = 2500,
): Promise<ProbeResult> {
  const started = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${base.replace(/\/+$/, '')}/api/health`, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    if (!res.ok) {
      return { url: base, ok: false, ms: Date.now() - started, error: `HTTP ${res.status}` };
    }
    const health = await res.json();
    return { url: base, ok: true, ms: Date.now() - started, health };
  } catch (e: any) {
    const error =
      e?.name === 'AbortError'
        ? 'не ответил за ' + (timeoutMs / 1000).toFixed(1) + ' с'
        : describeFetchError(e);
    return { url: base, ok: false, ms: Date.now() - started, error };
  } finally {
    clearTimeout(timer);
  }
}

/** Проверяет все вероятные адреса параллельно, возвращает живые. */
export async function discoverServers(port = DEFAULT_PORT): Promise<ProbeResult[]> {
  const urls = candidateUrls(port);
  const results = await Promise.all(urls.map((u) => probeServer(u, 2500)));
  return results.sort((a, b) => Number(b.ok) - Number(a.ok) || a.ms - b.ms);
}

/** Расстояние Левенштейна — для распознавания опечаток в схеме адреса. */
function editDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const row = [i];
    for (let j = 1; j <= n; j++) {
      row[j] = Math.min(
        prev[j] + 1,
        row[j - 1] + 1,
        prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    prev = row;
  }
  return prev[n];
}

function describeFetchError(e: any): string {
  const msg = String(e?.message || e || '');
  if (/Failed to fetch|NetworkError|load failed/i.test(msg)) {
    return 'сервера по этому адресу нет';
  }
  if (/ERR_CONNECTION_REFUSED/i.test(msg)) return 'соединение отклонено';
  if (/ERR_NAME_NOT_RESOLVED/i.test(msg)) return 'имя не найдено';
  if (/timeout/i.test(msg)) return 'таймаут';
  return msg.slice(0, 80) || 'неизвестная ошибка';
}

/** Человеческое объяснение того, почче��у не получилось подключиться. */
export function explainConnectionError(base: string, e: any): string {
  const url = base.replace(/\/+$/, '');
  if (e?.status) return e.message;

  // Проверяем, не опечатка ли в самом адресе — это самая частая причина.
  const norm = normalizeServerUrl(url);
  if (norm.invalid) {
    return `Адрес «${url}» неправильный: ${norm.note}`;
  }
  if (norm.fixed) {
    return `В адресе опечатка. Правильно: ${norm.url}`;
  }

  const isLocal = /127\.0\.0\.1|localhost|10\.0\.2\.2/.test(url);
  if (isLocal) {
    return (
      `По адресу ${url} сервера нет.\n` +
      'Сервер запускается на компьютере, а не внутри приложения.\n' +
      'На компьютере выполни:  setup\\start-server.cmd'
    );
  }
  return `Не удалось подключиться к ${url}. Проверь адрес и что сервер запущен.`;
}
