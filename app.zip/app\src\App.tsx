import { useCallback, useEffect, useState } from 'react';
import {
  api,
  cacheUser,
  getCachedUser,
  getToken,
  isLocalMode,
  setToken,
  type User,
} from './api';
import { PhoneScreen } from './screens/PhoneScreen';
import { CodeScreen } from './screens/CodeScreen';
import { HomeScreen } from './screens/HomeScreen';
import { ChatsScreen } from './screens/ChatsScreen';
import { ChatScreen } from './screens/ChatScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { Toast } from './components/Toast';
import { startRealtime, stopRealtime } from './realtime';

type Screen = 'phone' | 'code' | 'home' | 'chats' | 'chat' | 'profile' | 'settings';

export default function App() {
  const [screen, setScreen] = useState<Screen>('phone');
  const [user, setUser] = useState<User | null>(null);
  const [checking, setChecking] = useState(true);
  /** Сервер не отвечает, но вход уже был — показываем кэш профиля. */
  const [serverOffline, setServerOffline] = useState(false);

  // данные перехода phone -> code
  const [pendingPhone, setPendingPhone] = useState('');
  const [pendingCountry, setPendingCountry] = useState('ru');
  const [devCode, setDevCode] = useState<string | undefined>(undefined);

  const [toast, setToast] = useState('');
  const [openChatId, setOpenChatId] = useState('');

  const showToast = useCallback((m: string) => setToast(m), []);

  // восстановление сессии
  useEffect(() => {
    const boot = async () => {
      const token = getToken();
      if (!token) {
        setChecking(false);
        return;
      }
      try {
        const res = await api.me();
        setUser(res.user);
        cacheUser(res.user);
        setServerOffline(false);
        setScreen('home');
        if (!isLocalMode()) startRealtime();
      } catch (e: any) {
        if (e?.status === 0) {
          // Сеть недоступна. Токен не трогаем — он снова заработает,
          // как только сервер вернётся. Показываем кэш профиля.
          const cached = getCachedUser();
          if (cached) {
            setUser(cached);
            setServerOffline(true);
            setScreen('home');
          } else {
            setScreen('phone');
          }
        } else {
          // 401 и прочее — сессия действительно недействительна.
          setToken(null);
          cacheUser(null);
        }
      } finally {
        setChecking(false);
      }
    };
    boot();
  }, []);

  // Страховка: поток событий не должен висеть после размонтирования.
  useEffect(() => () => stopRealtime(), []);

  const handleCodeSent = (phone: string, country: string, dev?: string) => {
    setPendingPhone(phone);
    setPendingCountry(country);
    setDevCode(dev);
    setScreen('code');
  };

  const handleAuth = (token: string, u: User) => {
    setToken(token);
    setUser(u);
    cacheUser(u);
    setServerOffline(false);
    setDevCode(undefined);
    setScreen('home');
    if (!isLocalMode()) startRealtime();
    showToast(`Добро пожаловать, ${u.name}!`);
  };

  const handleLogout = () => {
    stopRealtime();
    setToken(null);
    cacheUser(null);
    setUser(null);
    setServerOffline(false);
    setDevCode(undefined);
    setOpenChatId('');
    setScreen('phone');
  };

  if (checking) {
    return (
      <div className="app">
        <div className="body body--center" style={{ alignItems: 'center' }}>
          <span className="spinner" />
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      {screen === 'phone' && (
        <PhoneScreen onCodeSent={(phone, country, dev) => handleCodeSent(phone, country, dev)} />
      )}

      {screen === 'code' && (
        <CodeScreen
          phone={pendingPhone}
          country={pendingCountry}
          devCode={devCode}
          onBack={() => setScreen('phone')}
          onDone={handleAuth}
          onToast={showToast}
        />
      )}

      {screen === 'home' && user && (
        <HomeScreen
          user={user}
          offline={serverOffline || isLocalMode()}
          onOpenProfile={() => setScreen('profile')}
          onOpenSettings={() => setScreen('settings')}
          onOpenChats={() => setScreen('chats')}
          onToast={showToast}
          onLogout={handleLogout}
        />
      )}

      {screen === 'chats' && (
        <ChatsScreen
          autonomous={isLocalMode()}
          onBack={() => setScreen('home')}
          onToast={showToast}
          onOpenChat={(id) => {
            setOpenChatId(id);
            setScreen('chat');
          }}
        />
      )}

      {screen === 'chat' && openChatId && (
        <ChatScreen chatId={openChatId} onBack={() => setScreen('chats')} onToast={showToast} />
      )}

      {screen === 'profile' && user && (
        <ProfileScreen
          user={user}
          onBack={() => setScreen('home')}
          onSaved={(u) => {
            setUser(u);
            cacheUser(u);
          }}
          onToast={showToast}
        />
      )}

      {screen === 'settings' && (
        <SettingsScreen
          onBack={() => setScreen('home')}
          onToast={showToast}
          onLoggedOut={handleLogout}
        />
      )}

      {toast && <Toast message={toast} onDone={() => setToast('')} />}
    </div>
  );
}
