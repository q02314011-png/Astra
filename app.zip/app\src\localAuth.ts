/**
 * Авторизация без сервера.
 *
 * Нужна для случая «приложение открыли, а сервер не запущен и в интернете его нет».
 * Вход полностью проходит на устройстве: код генерируется локально, профиль
 * хранится в localStorage. Никаких SMS при этом не отправляется — это честно
 * помечено в интерфейсе как автономный режим.
 *
 * Важно: данные не синхронизируются между устройствами. Это не мессенджер,
 * а способ открыть приложение и посмотреть, что оно работает.
 */
import type { User } from './api';

const USER_KEY = 'astra.local.user';
const CHALLENGE_KEY = 'astra.local.challenge';

const COLORS = [
  '#2AABEE',
  '#E17076',
  '#7BC862',
  '#E5CA77',
  '#A695E7',
  '#EE7AAE',
  '#6EC9CB',
  '#F2A35E',
];

function pickColor(seed: string): string {
  let h = 0;
  for (const ch of seed) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
}

function defaultName(phone: string): string {
  return `Astra ${String(phone).replace(/\D/g, '').slice(-4)}`;
}

function randomToken(): string {
  const g: any = globalThis as any;
  if (g.crypto?.randomUUID) return `local-${g.crypto.randomUUID()}`;
  const bytes = new Uint8Array(16);
  if (g.crypto?.getRandomValues) g.crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  return 'local-' + Array.from(bytes, (b: number) => b.toString(16).padStart(2, '0')).join('');
}

function randomCode(len = 5): string {
  const g: any = globalThis as any;
  const bytes = new Uint8Array(len);
  if (g.crypto?.getRandomValues) g.crypto.getRandomValues(bytes);
  else for (let i = 0; i < len; i++) bytes[i] = Math.floor(Math.random() * 10);
  return Array.from(bytes, (b: number) => String(b % 10)).join('');
}

function readJson<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function writeJson(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

type Challenge = {
  phone: string;
  code: string;
  createdAt: number;
  expiresAt: number;
  attempts: number;
  consumed: boolean;
  sentAt: number;
};

/** Автономный режим возможен всегда — он не зависит ни от чего внешнего. */
export const localAuthAvailable = true;

export function getLocalUser(): User | null {
  return readJson<User>(USER_KEY);
}

export function clearLocalUser(): void {
  try {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(CHALLENGE_KEY);
  } catch {}
}

export async function localRequestCode(phone: string): Promise<{
  ok: boolean;
  status: 'sent' | 'cooldown';
  provider: string;
  phoneHint: string;
  expiresIn: number;
  retryAfter: number;
  devCode?: string;
  notice?: string;
}> {
  const now = Date.now();
  const prev = readJson<Challenge>(CHALLENGE_KEY);

  if (prev && prev.phone === phone && !prev.consumed) {
    const since = Math.floor((now - prev.sentAt) / 1000);
    if (since < 60) {
      return {
        ok: true,
        status: 'cooldown',
        provider: 'local',
        phoneHint: phone,
        expiresIn: Math.max(0, Math.floor((prev.expiresAt - now) / 1000)),
        retryAfter: 60 - since,
      };
    }
  }

  const code = randomCode(5);
  writeJson(CHALLENGE_KEY, {
    phone,
    code,
    createdAt: now,
    expiresAt: now + 180_000,
    attempts: 0,
    consumed: false,
    sentAt: now,
  } satisfies Challenge);

  return {
    ok: true,
    status: 'sent',
    provider: 'local',
    phoneHint: phone,
    expiresIn: 180,
    retryAfter: 60,
    devCode: code,
    notice:
      'Автономный режим: код сгенерирован на устройстве, SMS не отправлялась. ' +
      'Данные не синхронизируются между устройствами.',
  };
}

export async function localVerifyCode(
  phone: string,
  code: string,
  name: string,
): Promise<{ ok: boolean; token: string; user: User }> {
  const ch = readJson<Challenge>(CHALLENGE_KEY);
  if (!ch || ch.phone !== phone || ch.consumed) {
    throw Object.assign(new Error('Код не найден. Запросите код ещё раз.'), { status: 400 });
  }
  if (Date.now() > ch.expiresAt) {
    throw Object.assign(new Error('Срок действия кода истёк. Запросите новый.'), { status: 400 });
  }
  if (ch.code !== code) {
    ch.attempts += 1;
    if (ch.attempts >= 5) ch.consumed = true;
    writeJson(CHALLENGE_KEY, ch);
    throw Object.assign(
      new Error(`Неверный код. Осталось попыток: ${Math.max(0, 5 - ch.attempts)}`),
      { status: 400 },
    );
  }
  ch.consumed = true;
  writeJson(CHALLENGE_KEY, ch);

  const existing = getLocalUser();
  const user: User =
    existing && existing.phone === phone
      ? { ...existing, name: name || existing.name, lastSeenAt: Date.now() }
      : {
          id: randomToken(),
          phone,
          name: name || defaultName(phone),
          bio: '',
          avatarColor: pickColor(phone),
          createdAt: Date.now(),
        };
  writeJson(USER_KEY, user);
  return { ok: true, token: randomToken(), user };
}

export async function localMe(): Promise<{ ok: boolean; user: User }> {
  const user = getLocalUser();
  if (!user) throw Object.assign(new Error('Сессия не найдена'), { status: 401 });
  return { ok: true, user };
}

export async function localUpdateMe(patch: {
  name?: string;
  bio?: string;
}): Promise<{ ok: boolean; user: User }> {
  const user = getLocalUser();
  if (!user) throw Object.assign(new Error('Сессия не найдена'), { status: 401 });
  if (patch.name) user.name = patch.name.trim().slice(0, 64);
  if (patch.bio !== undefined) user.bio = patch.bio.slice(0, 140);
  writeJson(USER_KEY, user);
  return { ok: true, user };
}

export async function localHealth(): Promise<{
  ok: boolean;
  app: string;
  mode: string;
  provider: string;
  providerStatus: { ok: boolean; balance: null; detail: string };
  stats: Record<string, number>;
}> {
  const user = getLocalUser();
  return {
    ok: true,
    app: 'Astra',
    mode: 'local',
    provider: 'local',
    providerStatus: {
      ok: true,
      balance: null,
      detail: 'автономный режим: сервер не используется, SMS не отправляются',
    },
    stats: { users: user ? 1 : 0, localOnly: 1 },
  };
}

/**
 * Чатов в автономном режиме нет: переписка существует только на сервере,
 * где её видят оба участника. Возвращаем пустой список с объяснением,
 * чтобы интерфейс не показывал ошибку.
 */
export async function localChats(): Promise<{ ok: boolean; chats: []; unreadTotal: 0 }> {
  return { ok: true, chats: [], unreadTotal: 0 };
}
