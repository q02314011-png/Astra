/** Работа с номерами телефона на клиенте. */

/** Локальная часть номера без кода страны, с учётом ведущей 8 для RU/KZ. */
export function normalizeLocal(input: string, countryCode: string): string | null {
  let s = String(input || '').replace(/\D/g, '');
  if (!s) return null;
  if (s.startsWith('00')) s = s.slice(2);
  if (s.length === 11 && s.startsWith('8') && (countryCode === 'ru' || countryCode === 'kz')) {
    s = s.slice(1);
  }
  return s || null;
}

/** Склеивает локальную часть с кодом страны в полный номер. */
export function fullPhone(local: string, dial: string): string {
  let l = local.replace(/\D/g, '');
  if (l.startsWith('00')) l = l.slice(2);
  if (l.length === 11 && l.startsWith('8')) l = l.slice(1);
  if (l.startsWith(dial)) return l;
  return dial + l;
}

/** Приводит номер к E.164 (+7...). */
export function normalizePhone(input: string | null | undefined): string | null {
  if (input === null || input === undefined) return null;
  const raw = String(input).trim();
  if (!raw) return null;

  const hasPlus = raw.startsWith('+');
  let s = raw.replace(/\D/g, '');
  if (!s) return null;

  if (s.startsWith('00')) s = s.slice(2);
  else if (!hasPlus && s.length > 11) s = s.slice(-11);

  if (s.length === 11 && s.startsWith('8')) s = `7${s.slice(1)}`;
  if (s.length < 7 || s.length > 15) return null;
  return `+${s}`;
}

/** Маскирование для показа: +7 ••• ••• 45 67 */
export function maskPhone(phone: string): string {
  const d = String(phone).replace(/\D/g, '');
  if (d.length < 5) return phone;
  return `+${d.slice(0, 3)} ••• ••• ${d.slice(-2)}`;
}
