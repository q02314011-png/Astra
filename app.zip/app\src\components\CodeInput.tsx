import { useEffect, useRef, useState } from 'react';

export function CodeInput({
  length = 5,
  value,
  onChange,
  onComplete,
  disabled,
  error,
}: {
  length?: number;
  value: string;
  onChange: (v: string) => void;
  onComplete?: (v: string) => void;
  disabled?: boolean;
  error?: boolean;
}) {
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const [focused, setFocused] = useState(0);

  useEffect(() => {
    refs.current[0]?.focus();
  }, []);

  const setAt = (index: number, char: string) => {
    const cells = value.split('');
    while (cells.length < length) cells.push('');
    cells[index] = char;
    const next = cells.join('').slice(0, length);
    onChange(next);
    return next;
  };

  const handleChange = (index: number, raw: string) => {
    const digits = raw.replace(/\D/g, '');
    if (!digits) {
      const cells = value.split('');
      cells[index] = '';
      onChange(cells.join('').trimEnd() || '');
      return;
    }
    // вставка нескольких цифр сразу (например, из буфера)
    if (digits.length > 1) {
      const cells = value.padEnd(length, ' ').split('');
      digits.split('').forEach((d, i) => {
        if (index + i < length) cells[index + i] = d;
      });
      const next = cells.join('').slice(0, length);
      onChange(next);
      const target = Math.min(index + digits.length, length - 1);
      refs.current[target]?.focus();
      if (next.length === length) onComplete?.(next);
      return;
    }
    const next = setAt(index, digits);
    if (index < length - 1) {
      refs.current[index + 1]?.focus();
    } else if (next.length === length) {
      onComplete?.(next);
    }
  };

  const handleKey = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      const cur = value[index];
      if (cur) {
        const cells = value.padEnd(length, ' ').split('');
        cells[index] = '';
        onChange(cells.join('').replace(/\s+$/, ''));
      } else if (index > 0) {
        const cells = value.padEnd(length, ' ').split('');
        cells[index - 1] = '';
        onChange(cells.join('').replace(/\s+$/, ''));
        refs.current[index - 1]?.focus();
      }
    }
    if (e.key === 'ArrowLeft' && index > 0) refs.current[index - 1]?.focus();
    if (e.key === 'ArrowRight' && index < length - 1) refs.current[index + 1]?.focus();
  };

  const cells = value.padEnd(length, ' ').split('').slice(0, length);

  return (
    <div className="code-inputs">
      {cells.map((c, i) => (
        <input
          key={i}
          ref={(el) => (refs.current[i] = el)}
          className={`code-cell ${c.trim() ? 'code-cell--filled' : ''}`}
          style={
            error
              ? { borderColor: 'var(--danger)' }
              : focused === i
                ? { borderColor: 'var(--accent-strong)' }
                : undefined
          }
          value={c.trim()}
          inputMode="numeric"
          autoComplete={i === 0 ? 'one-time-code' : 'off'}
          maxLength={length}
          disabled={disabled}
          onFocus={() => setFocused(i)}
          onChange={(e) => handleChange(i, e.target.value)}
          onKeyDown={(e) => handleKey(i, e)}
          onPaste={(e) => {
            e.preventDefault();
            handleChange(i, e.clipboardData.getData('text'));
          }}
        />
      ))}
    </div>
  );
}
