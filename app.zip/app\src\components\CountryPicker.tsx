import { useMemo, useState } from 'react';
import { LOCAL_COUNTRIES, type Country } from '../api';

export function CountryPicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (iso: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');

  const current = useMemo(
    () => LOCAL_COUNTRIES.find((c) => c.code === value) || LOCAL_COUNTRIES[0],
    [value],
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return LOCAL_COUNTRIES;
    return LOCAL_COUNTRIES.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.dial.includes(q) ||
        c.code.includes(q) ||
        c.flag.includes(q),
    );
  }, [query]);

  const pick = (c: Country) => {
    onChange(c.code);
    setOpen(false);
    setQuery('');
  };

  return (
    <>
      <button type="button" className="country-btn" onClick={() => setOpen(true)}>
        <span className="country-btn__flag">{current.flag}</span>
        <span>+{current.dial}</span>
        <span className="country-btn__caret">▼</span>
      </button>

      {open && (
        <div className="modal-backdrop" onClick={() => setOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal__head">
              <div className="modal__title">Выберите страну</div>
              <button className="modal__close" onClick={() => setOpen(false)}>
                ×
              </button>
            </div>
            <div style={{ padding: '10px 14px 4px' }}>
              <input
                className="input"
                placeholder="Поиск страны"
                value={query}
                autoFocus
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="modal__list">
              {filtered.length === 0 && (
                <div style={{ padding: '20px 18px', color: 'var(--text-2)' }}>
                  Ничего не найдено
                </div>
              )}
              {filtered.map((c) => (
                <button
                  key={c.code}
                  className={`country-row ${c.code === value ? 'country-row--active' : ''}`}
                  onClick={() => pick(c)}
                >
                  <span style={{ fontSize: 20 }}>{c.flag}</span>
                  <span>{c.name}</span>
                  <span className="country-row__dial">+{c.dial}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
