export type BannerKind = 'info' | 'warn' | 'error' | 'ok';
