import type { BannerKind } from '../types';

export function Banner({
  kind = 'info',
  icon,
  children,
}: {
  kind?: BannerKind;
  icon?: string;
  children: React.ReactNode;
}) {
  const defaultIcon = kind === 'error' ? '⚠' : kind === 'warn' ? '⚠' : kind === 'ok' ? '✓' : 'ℹ';
  return (
    <div className={`banner banner--${kind}`}>
      <span className="banner__icon">{icon ?? defaultIcon}</span>
      <div>{children}</div>
    </div>
  );
}
