import { useEffect, useRef, useState } from 'react';
import { api, ApiError, isLocalMode, type User } from '../api';
import { Banner } from '../components/Banner';
import { CodeInput } from '../components/CodeInput';
import { Avatar } from '../components/Avatar';

export function CodeScreen({
  phone,
  country,
  devCode,
  onBack,
  onDone,
  onToast,
}: {
  phone: string;
  country: string;
  devCode?: string;
  onBack: () => void;
  onDone: (token: string, user: User) => void;
  onToast: (m: string) => void;
}) {
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [secondsLeft, setSecondsLeft] = useState(60);
  const [expiresIn, setExpiresIn] = useState(0);
  const autoSubmitted = useRef(false);

  useEffect(() => {
    const t = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (expiresIn <= 0) return;
    const t = setInterval(() => setExpiresIn((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [expiresIn]);

  const submit = async (value?: string) => {
    const finalCode = (value ?? code).replace(/\D/g, '');
    if (finalCode.length < 4) {
      setError('Введите код полностью');
      return;
    }
    setBusy(true);
    setError('');
    try {
      const res = await api.verifyCode(phone, finalCode, '');
      onDone(res.token, res.user);
    } catch (e) {
      const err = e as ApiError;
      setError(err.message || 'Неверный код');
      if (err.payload?.needNewCode) setSecondsLeft(0);
    } finally {
      setBusy(false);
    }
  };

  // автоотправка, как только введено 5 цифр
  const handleComplete = (v: string) => {
    setCode(v);
    if (!autoSubmitted.current && !busy) {
      autoSubmitted.current = true;
      submit(v);
      setTimeout(() => (autoSubmitted.current = false), 1500);
    }
  };

  const resend = async () => {
    setError('');
    setNotice('');
    setBusy(true);
    try {
      const res = await api.requestCode(phone, country, '');
      if (res.devCode) {
        setNotice(`Новый код: ${res.devCode}`);
        onToast(`Код обновлён: ${res.devCode}`);
      } else {
        setNotice('Новый код отправлен');
      }
      setSecondsLeft(res.retryAfter || 60);
      setExpiresIn(res.expiresIn || 180);
    } catch (e) {
      setError((e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };

  const masked = mask(phone);
  const offline = isLocalMode();

  return (
    <>
      <div className="header">
        <button className="header__back" onClick={onBack} aria-label="Назад">
          ‹
        </button>
        <div className="header__title">Проверка кода</div>
      </div>

      <div className="body body--center">
        <div style={{ textAlign: 'center', marginBottom: 22 }}>
          <Avatar name={masked} color="#2b5278" />
          <div style={{ fontSize: 17, fontWeight: 600, marginTop: 12 }}>
            Введите код
          </div>
          <div className="hint" style={{ marginTop: 4 }}>
            {offline ? 'Кот создан на этом устройстве для' : 'Мы отправили код подтверждения на номер'}
            <br />
            <span className="mono">{masked}</span>
          </div>
        </div>

        {offline && (
          <Banner kind="info">
            Автономный режим: сервера нет, код сгенерирован на устройстве. SMS не
            отправлялась, аккаунт существует только здесь.
          </Banner>
        )}

        {devCode && (
          <div className="dev-code">
            <div className="dev-code__label">
              {offline ? 'код подтверждения (автономно)' : 'тестовый режим — код подтверждения'}
            </div>
            <div className="dev-code__value">{devCode}</div>
          </div>
        )}

        {notice && !devCode && <Banner kind="ok">{notice}</Banner>}
        {error && <Banner kind="error">{error}</Banner>}

        <CodeInput
          value={code}
          onChange={(v) => {
            setCode(v);
            if (error) setError('');
          }}
          onComplete={handleComplete}
          disabled={busy}
          error={Boolean(error)}
        />

        <button className="btn" onClick={() => submit()} disabled={busy || code.length < 4}>
          {busy ? (
            <>
              <span className="spinner" /> Проверяем…
            </>
          ) : (
            'Продолжить'
          )}
        </button>

        <div style={{ textAlign: 'center', marginTop: 18 }}>
          {secondsLeft > 0 ? (
            <span className="hint">
              Отправить код повторно через <span className="mono">{secondsLeft}с</span>
            </span>
          ) : (
            <span className="link" onClick={resend}>
              Отправить код повторно
            </span>
          )}
        </div>

        {expiresIn > 0 && (
          <div className="footer-note">
            Код действует {Math.floor(expiresIn / 60)} мин {expiresIn % 60} с
          </div>
        )}
      </div>
    </>
  );
}

function mask(phone: string) {
  const d = phone.replace(/\D/g, '');
  if (d.length < 5) return phone;
  return `+${d.slice(0, 3)} ••• ••• ${d.slice(-2)}`;
}
