import { useEffect, useState } from 'react';
import {
  LOCAL_COUNTRIES,
  api,
  ApiError,
  deviceId,
  setCountry,
  setLastPhone,
  getCountry,
  getLastPhone,
  getServerUrl,
  isLocalMode,
  setMode,
  setServerUrl,
} from '../api';
import { discoverServers, probeServer, type ProbeResult } from '../net';
import { Logo, Wordmark } from '../components/Logo';
import { CountryPicker } from '../components/CountryPicker';
import { Banner } from '../components/Banner';
import { normalizeLocal } from '../phone';

export function PhoneScreen({
  onCodeSent,
}: {
  onCodeSent: (phone: string, country: string, devCode?: string) => void;
}) {
  const [country, setCountryIso] = useState(getCountry());
  const [phone, setPhone] = useState(getLastPhone());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  // сервер недоступен — предлагаем автономный режим
  const [offline, setOffline] = useState<boolean>(() => isLocalMode());
  const [searching, setSearching] = useState(false);
  const [found, setFound] = useState<ProbeResult[]>([]);

  const c = LOCAL_COUNTRIES.find((x) => x.code === country) || LOCAL_COUNTRIES[0];

  // При открытии экрана один раз проверяем, есть ли сервер.
  useEffect(() => {
    if (isLocalMode()) return;
    let alive = true;
    probeServer(getServerUrl(), 3000).then((r) => {
      if (alive && !r.ok) setOffline(true);
    });
    return () => {
      alive = false;
    };
  }, []);

  const search = async () => {
    setSearching(true);
    setError('');
    try {
      const results = await discoverServers();
      setFound(results);
      const live = results.find((r) => r.ok);
      if (live) {
        setServerUrl(live.url);
        setOffline(false);
        setError('');
      } else {
        setOffline(true);
      }
    } finally {
      setSearching(false);
    }
  };

  const useLocalMode = () => {
    setMode('local');
    setOffline(true);
    setError('');
  };

  const submit = async () => {
    setError('');
    const local = normalizeLocal(phone, c.code);
    if (!local) {
      setError('Введите номер телефона');
      return;
    }
    if (local.length < 4) {
      setError('Слишком короткий номер');
      return;
    }

    setBusy(true);
    try {
      // В автономном режиме сервера нет, поэтому номер передаём полным —
      // так он отображается и в профиле, и в коде подтверждения.
      const argPhone = isLocalMode() ? `+${c.dial}${local}` : local;
      const res = await api.requestCode(argPhone, country, deviceId());
      const full = res.phoneHint || `+${c.dial}${local}`;
      setCountry(country);
      setLastPhone(local);
      onCodeSent(full, country, res.devCode);
    } catch (e) {
      const err = e as ApiError;
      if (err.status === 0) {
        // Сеть недоступна — не тупим, а сразу предлагаем автономный режим.
        setOffline(true);
        setError(err.message);
      } else if (err.status === 429) {
        setError(err.message);
      } else {
        setError(err.message || 'Не удалось отправить код');
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <div className="header">
        <div className="header__title">Вход в Astra</div>
      </div>

      <div className="body body--center">
        <div>
          <Logo />
          <Wordmark tagline="безопасный мессенджер" />
        </div>

        <div style={{ marginTop: 28 }}>
          {error && <Banner kind="error">{error}</Banner>}

          {isLocalMode() ? (
            <Banner kind="warn">
              Автономный режим: сервер не нужен. Вход и профиль работают на этом
              устройстве, SMS не отправляются, данные не синхронизируются. Включить
              сервер можно в настройках.
            </Banner>
          ) : (
            offline && (
              <Banner kind="warn">
                <div style={{ marginBottom: 8 }}>
                  Сервер недоступен. Можно войти <b>без сервера</b> — вход и профиль будут
                  работать прямо на устройстве. SMS при этом не отправляется, данные
                  не синхронизируются.
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  <button className="btn btn--sm" onClick={useLocalMode}>
                    Войти без сервера
                  </button>
                  <button className="btn btn--sm btn--ghost" onClick={search} disabled={searching}>
                    {searching ? 'Ищем сервер…' : 'Найти сервер'}
                  </button>
                </div>
                {found.length > 0 && (
                  <div className="probe-list">
                    {found.map((r) => (
                      <div key={r.url} className="probe">
                        <span
                          className={`status-dot ${r.ok ? 'status-dot--on' : 'status-dot--off'}`}
                        />
                        <span className="probe__url mono">{r.url}</span>
                        <span className="probe__state">{r.ok ? 'отвечает' : r.error}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Banner>
            )
          )}

          <div className="field">
            <label className="field__label">Ваш номер телефона</label>
            <div className="input-group">
              <CountryPicker
                value={country}
                onChange={(iso) => {
                  setCountryIso(iso);
                  setCountry(iso);
                }}
              />
              <input
                className={`input ${error ? 'input--error' : ''}`}
                inputMode="tel"
                autoComplete="tel-national"
                placeholder="000 000 00 00"
                value={phone}
                disabled={busy}
                onChange={(e) => setPhone(e.target.value.replace(/[^\d\s()\-]/g, ''))}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') submit();
                }}
              />
            </div>
          </div>

          <button className="btn" onClick={submit} disabled={busy || !phone.trim()}>
            {busy ? (
              <>
                <span className="spinner" /> Отправляем код…
              </>
            ) : (
              'Далее'
            )}
          </button>

          <div className="footer-note">
            {isLocalMode() ? (
              <>Автономный режим — код появится на следующем экране</>
            ) : (
              <>
                Нажмите «Далее», чтобы получить код подтверждения на номер
                <br />
                <span className="mono">+{c.dial}</span> {phone || '—'}
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
