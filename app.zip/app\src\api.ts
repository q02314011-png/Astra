/**
 * Клиент API Astra. Базовый адрес сервера можно менять в настройках —
 * он сохраняется локально, поэтому один APK/EXE работает с любым ПК в сети.
 *
 * Если сервера нет вообще, есть автономный режим: вход и профиль работают
 * на устройстве, см. localAuth.ts.
 */
import { normalizeServerUrl, explainConnectionError } from './net';
import * as local from './localAuth';

export type User = {
  id: string;
  phone: string;
  name: string;
  bio: string;
  avatarColor: string;
  createdAt: number;
  lastSeenAt?: number;
};

export type Country = { code: string; dial: string; name: string; flag: string };

/** Диалог в списке чатов. */
export type Chat = {
  id: string;
  updatedAt: number;
  unread: number;
  peer: User | null;
  lastMessage: { id: string; text: string; at: number; mine: boolean } | null;
};

export type Message = {
  id: string;
  chatId: string;
  text: string;
  at: number;
  mine: boolean;
  read: boolean;
};

/** Событие из потока /api/events. */
export type RealtimeEvent =
  | { type: 'hello'; userId: string; at: number }
  | { type: 'message'; chatId: string; message: Message }
  | { type: 'read'; chatId: string; byUserId: string; at: number }
  | { type: 'presence'; online: string[] };

const STORAGE_KEY = 'astra.server.url';
const TOKEN_KEY = 'astra.token';
const PHONE_KEY = 'astra.phone';
const COUNTRY_KEY = 'astra.country';
const MODE_KEY = 'astra.mode';
const LAST_USER_KEY = 'astra.last.user';

declare global {
  interface Window {
    __ASTRA_DESKTOP__?: boolean;
    __ASTRA_ANDROID__?: boolean;
  }
}

export function isNativeAndroid(): boolean {
  const w = window as any;
  if (w.__ASTRA_ANDROID__) return true;
  const cap = (globalThis as any).Capacitor;
  return Boolean(cap?.isNativePlatform?.() && cap.getPlatform() === 'android');
}

export function isDesktop(): boolean {
  return Boolean(window.__ASTRA_DESKTOP__);
}

/**
 * Адрес по умолчанию:
 *  - Android-эмулятор  → 10.0.2.2 (хост с точки зрения гостевой VM)
 *  - Windows/браузер  → 127.0.0.1
 */
export function defaultServerUrl(): string {
  if (isNativeAndroid()) return 'http://10.0.2.2:4000';
  return 'http://127.0.0.1:4000';
}

export function getServerUrl(): string {
  try {
    return localStorage.getItem(STORAGE_KEY) || defaultServerUrl();
  } catch {
    return defaultServerUrl();
  }
}

/**
 * Сохраняет адрес, попутно чинит очевидные опечатки:
 * «127.0.0.01:4000» превращается в «http://127.0.0.1:4000».
 */
export function setServerUrl(url: string): { url: string; fixed: boolean; note?: string } {
  const norm = normalizeServerUrl(url || defaultServerUrl());
  const value = norm.invalid ? (url || '').trim() : norm.url;
  try {
    localStorage.setItem(STORAGE_KEY, value);
  } catch {}
  return { url: value, fixed: !!norm.fixed, note: norm.note };
}

/** Режим работы: 'server' — через сервер, 'local' — автономно. */
export type Mode = 'server' | 'local';

export function getMode(): Mode {
  try {
    return localStorage.getItem(MODE_KEY) === 'local' ? 'local' : 'server';
  } catch {
    return 'server';
  }
}

export function isLocalMode(): boolean {
  return getMode() === 'local';
}

export function setMode(mode: Mode): void {
  try {
    localStorage.setItem(MODE_KEY, mode);
  } catch {}
}

export function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string | null): void {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

/**
 * Последний известный профиль. Нужен на случай, когда сервер временно недоступен:
 * показываем кэш, а не выкидываем пользователя на экран входа.
 */
export function cacheUser(user: User | null): void {
  try {
    if (user) localStorage.setItem(LAST_USER_KEY, JSON.stringify(user));
    else localStorage.removeItem(LAST_USER_KEY);
  } catch {}
}

export function getCachedUser(): User | null {
  try {
    const raw = localStorage.getItem(LAST_USER_KEY);
    return raw ? (JSON.parse(raw) as User) : null;
  } catch {
    return null;
  }
}

export function getLastPhone(): string {
  try {
    return localStorage.getItem(PHONE_KEY) || '';
  } catch {
    return '';
  }
}

export function setLastPhone(v: string): void {
  try {
    localStorage.setItem(PHONE_KEY, v);
  } catch {}
}

export function getCountry(): string {
  try {
    return localStorage.getItem(COUNTRY_KEY) || guessCountry();
  } catch {
    return guessCountry();
  }
}

export function setCountry(iso: string): void {
  try {
    localStorage.setItem(COUNTRY_KEY, iso);
  } catch {}
}

function guessCountry(): string {
  const lang = typeof navigator !== 'undefined' ? navigator.language || '' : '';
  if (/^ru/i.test(lang)) return 'ru';
  if (/^uk/i.test(lang)) return 'ua';
  if (/^kz/i.test(lang)) return 'kz';
  if (/^by/i.test(lang)) return 'by';
  if (/^uz/i.test(lang)) return 'uz';
  return 'ru';
}

export class ApiError extends Error {
  status: number;
  payload: any;
  constructor(message: string, status: number, payload?: any) {
    super(message);
    this.status = status;
    this.payload = payload;
  }
}

async function request<T>(
  path: string,
  init: RequestInit & { timeoutMs?: number } = {},
): Promise<T> {
  const base = getServerUrl();
  const url = `${base}${path}`;
  const controller = new AbortController();
  const timeoutMs = init.timeoutMs ?? 15000;
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((init.headers as Record<string, string>) || {}),
  };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  try {
    const res = await fetch(url, { ...init, headers, signal: controller.signal });
    const text = await res.text();
    let data: any = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = { error: text.slice(0, 200) };
      }
    }
    if (!res.ok) {
      throw new ApiError(data?.error || `Ошибка ${res.status}`, res.status, data);
    }
    return data as T;
  } catch (e: any) {
    if (e instanceof ApiError) throw e;
    if (e?.name === 'AbortError') {
      throw new ApiError(`Сервер по адресу ${base} не отвечает.`, 0);
    }
    throw new ApiError(explainConnectionError(base, e), 0);
  } finally {
    clearTimeout(timer);
  }
}

export const api = {
  health: () =>
    isLocalMode()
      ? local.localHealth()
      : request<{
          ok: boolean;
          app: string;
          mode: string;
          provider: string;
          providerStatus: { ok: boolean; balance: number | null; detail: string };
          stats: Record<string, number>;
        }>('/api/health', { timeoutMs: 8000 }),

  countries: () => request<{ ok: boolean; countries: Country[] }>('/api/countries'),

  requestCode: (phone: string, country: string, deviceId: string) =>
    isLocalMode()
      ? local.localRequestCode(phone)
      : request<{
          ok: boolean;
          status: 'sent' | 'cooldown';
          provider: string;
          phoneHint: string;
          expiresIn: number;
          retryAfter: number;
          devCode?: string;
          notice?: string;
        }>('/api/auth/request-code', {
          method: 'POST',
          body: JSON.stringify({ phone, country, deviceId }),
          timeoutMs: 100000, // провайдер может ждать SMS до 90 секунд
        }),

  verifyCode: (phone: string, code: string, name: string) =>
    isLocalMode()
      ? local.localVerifyCode(phone, code, name)
      : request<{ ok: boolean; token: string; user: User }>('/api/auth/verify-code', {
          method: 'POST',
          body: JSON.stringify({ phone, code, name, deviceId: deviceId() }),
          timeoutMs: 20000,
        }),

  me: () =>
    isLocalMode()
      ? local.localMe()
      : request<{ ok: boolean; user: User }>('/api/me', { timeoutMs: 10000 }),

  updateMe: (patch: { name?: string; bio?: string }) =>
    isLocalMode()
      ? local.localUpdateMe(patch)
      : request<{ ok: boolean; user: User }>('/api/me', {
          method: 'PATCH',
          body: JSON.stringify(patch),
        }),

  logout: () =>
    isLocalMode()
      ? (async () => {
          local.clearLocalUser();
          return { ok: true };
        })()
      : request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),

  // ── чаты ──────────────────────────────────────────────────────
  chats: () =>
    isLocalMode()
      ? local.localChats()
      : request<{ ok: boolean; chats: Chat[]; unreadTotal: number }>('/api/chats'),

  chat: (chatId: string) =>
    request<{ ok: boolean; chat: Chat }>(`/api/chats/${encodeURIComponent(chatId)}`),

  openChat: (phone: string, country: string) =>
    request<{ ok: boolean; chat: Chat }>('/api/chats', {
      method: 'POST',
      body: JSON.stringify({ phone, country }),
      timeoutMs: 15000,
    }),

  messages: (chatId: string, before?: number) =>
    request<{
      ok: boolean;
      messages: Message[];
      hasMore: boolean;
    }>(`/api/chats/${encodeURIComponent(chatId)}/messages${before ? `?before=${before}` : ''}`),

  sendMessage: (chatId: string, text: string) =>
    request<{ ok: boolean; message: Message }>(
      `/api/chats/${encodeURIComponent(chatId)}/messages`,
      { method: 'POST', body: JSON.stringify({ text }) },
    ),

  markRead: (chatId: string) =>
    request<{ ok: boolean; fresh: number }>(
      `/api/chats/${encodeURIComponent(chatId)}/read`,
      { method: 'POST' },
    ),

  searchContacts: (q: string) =>
    request<{ ok: boolean; results: User[] & { online?: boolean }[] }>(
      `/api/contacts/search?q=${encodeURIComponent(q)}`,
    ),
};

export function deviceId(): string {
  const KEY = 'astra.device.id';
  try {
    let v = localStorage.getItem(KEY);
    if (!v) {
      v = `d-${Math.random().toString(36).slice(2)}-${Date.now().toString(36)}`;
      localStorage.setItem(KEY, v);
    }
    return v;
  } catch {
    return 'd-anonymous';
  }
}

/** Локальные страны (копия серверного списка — работает и без сети). */
export const LOCAL_COUNTRIES: Country[] = [
  { code: 'ru', dial: '7', name: 'Россия', flag: '🇷🇺' },
  { code: 'ua', dial: '380', name: 'Украина', flag: '🇺🇦' },
  { code: 'by', dial: '375', name: 'Беларусь', flag: '🇧🇾' },
  { code: 'kz', dial: '7', name: 'Казахстан', flag: '🇰🇿' },
  { code: 'uz', dial: '998', name: 'Узбекистан', flag: '🇺🇿' },
  { code: 'kg', dial: '996', name: 'Кыргызстан', flag: '🇰🇬' },
  { code: 'tj', dial: '992', name: 'Таджикистан', flag: '🇹🇯' },
  { code: 'tm', dial: '993', name: 'Туркменистан', flag: '🇹🇲' },
  { code: 'am', dial: '374', name: 'Армения', flag: '🇦🇲' },
  { code: 'az', dial: '994', name: 'Азербайджан', flag: '🇦🇿' },
  { code: 'ge', dial: '995', name: 'Грузия', flag: '🇬🇪' },
  { code: 'md', dial: '373', name: 'Молдова', flag: '🇲🇩' },
  { code: 'pl', dial: '48', name: 'Польша', flag: '🇵🇱' },
  { code: 'de', dial: '49', name: 'Германия', flag: '🇩🇪' },
  { code: 'us', dial: '1', name: 'США', flag: '🇺🇸' },
  { code: 'gb', dial: '44', name: 'Великобритания', flag: '🇬🇧' },
  { code: 'tr', dial: '90', name: 'Турция', flag: '🇹🇷' },
  { code: 'fr', dial: '33', name: 'Франция', flag: '🇫🇷' },
  { code: 'es', dial: '34', name: 'Испания', flag: '🇪🇸' },
  { code: 'it', dial: '39', name: 'Италия', flag: '🇮🇹' },
  { code: 'br', dial: '55', name: 'Бразилия', flag: '🇧🇷' },
  { code: 'in', dial: '91', name: 'Индия', flag: '🇮🇳' },
];
