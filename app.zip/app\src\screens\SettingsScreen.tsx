import { useState } from 'react';
import {
  api,
  ApiError,
  getMode,
  getServerUrl,
  isDesktop,
  isLocalMode,
  isNativeAndroid,
  setMode,
  setServerUrl,
} from '../api';
import { discoverServers, normalizeServerUrl, type ProbeResult } from '../net';
import { Banner } from '../components/Banner';

export function SettingsScreen({
  onBack,
  onToast,
  onLoggedOut,
}: {
  onBack: () => void;
  onToast: (m: string) => void;
  onLoggedOut: () => void;
}) {
  const [url, setUrl] = useState(getServerUrl());
  const [busy, setBusy] = useState(false);
  const [searching, setSearching] = useState(false);
  const [health, setHealth] = useState<any>(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');
  const [probes, setProbes] = useState<ProbeResult[]>([]);
  const [autonomous, setAutonomous] = useState(getMode() === 'local');

  const check = async () => {
    setError('');
    setNote('');
    setHealth(null);
    setBusy(true);
    try {
      const saved = setServerUrl(url);
      if (saved.fixed && saved.note) setNote(saved.note);
      setUrl(saved.url);
      const h = await api.health();
      setHealth(h);
      setAutonomous(getMode() === 'local');
    } catch (e) {
      setError((e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };

  const search = async () => {
    setSearching(true);
    setError('');
    setNote('');
    try {
      const results = await discoverServers();
      setProbes(results);
      const live = results.find((r) => r.ok);
      if (live) {
        setUrl(live.url);
        setServerUrl(live.url);
        setNote(`Найден сервер: ${live.url} (${live.ms} мс)`);
      } else {
        setNote('Ни один адрес не ответил — сервер не запущен на этом устройстве.');
      }
    } finally {
      setSearching(false);
    }
  };

  // Подсвечиваем поле только при настоящей опечатке. Дописанная схема
  // (ввели «astra.example.com») — это норма, а не ошибка.
  const preview = normalizeServerUrl(url);
  const previewTypo = !preview.invalid && !!preview.fixed && !!preview.typo;

  return (
    <>
      <div className="header">
        <button className="header__back" onClick={onBack}>
          ‹
        </button>
        <div className="header__title">Настройки</div>
      </div>
      <div className="body">
        <div className="section-title">Режим работы</div>
        <div className="row" style={{ cursor: 'default' }}>
          <div className="row__body">
            <div className="row__title">Автономный режим</div>
            <div className="row__sub">
              {autonomous
                ? 'включён — сервер не нужен, вход и профиль на устройстве'
                : 'выключен — вход через сервер Astra'}
            </div>
          </div>
          <span className="row__value">{autonomous ? 'вкл' : 'выкл'}</span>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button
            className="btn btn--sm"
            onClick={() => {
              setMode('local');
              setAutonomous(true);
              setHealth(null);
              onToast('Автономный режим включён — сервер больше не нужен');
            }}
            disabled={autonomous}
          >
            Работать без сервера
          </button>
          <button
            className="btn btn--sm btn--ghost"
            onClick={() => {
              setMode('server');
              setAutonomous(false);
              setHealth(null);
              onToast('Режим сервера включён');
            }}
            disabled={!autonomous}
          >
            Через сервер
          </button>
        </div>

        {autonomous && (
          <Banner kind="info">
            Сейчас приложение работает полностью на этом устройстве: вход по номеру,
            профиль, смена имени. SMS не отправляются, история и чаты не синхронизируются
            между устройствами. Это режим для проверки интерфейса без сервера.
          </Banner>
        )}

        <div className="divider" />
        <div className="section-title">Сервер</div>
        <div className="field">
          <label className="field__label">Адрес сервера Astra</label>
          <input
            className="input mono"
            value={url}
            placeholder="http://192.168.1.10:4000"
            onChange={(e) => setUrl(e.target.value)}
            autoCapitalize="off"
            autoCorrect="off"
            disabled={autonomous}
          />
          {previewTypo && (
            <div className="field__hint">
              Похоже на опечатку — будет использовано{' '}
              <span className="mono">{preview.url}</span>
            </div>
          )}
          {!preview.invalid && !previewTypo && preview.fixed && (
            <div className="field__hint" style={{ color: 'var(--text-3)' }}>
              будет использовано <span className="mono">{preview.url}</span>
            </div>
          )}
          {preview.invalid && <div className="field__hint">Адрес неправильный: {preview.note}</div>}
        </div>

        {isNativeAndroid() && (
          <Banner kind="info">
            На эмуляторе Android адрес хоста — <span className="mono">10.0.2.2</span>. На реальном
            телефоне укажи IP компьютера в локальной сети, например{' '}
            <span className="mono">http://192.168.1.10:4000</span>.
          </Banner>
        )}
        {isDesktop() && (
          <Banner kind="info">
            В настольной версии по умолчанию <span className="mono">http://127.0.0.1:4000</span> —
            это сервер, запущенный на этом же компьютере.
          </Banner>
        )}

        {note && <Banner kind="ok">{note}</Banner>}
        {error && <Banner kind="error">{error}</Banner>}

        <button className="btn" onClick={check} disabled={busy || autonomous}>
          {busy ? 'Проверяем…' : 'Сохранить и проверить'}
        </button>
        <button
          className="btn btn--ghost"
          onClick={search}
          disabled={searching}
          style={{ marginTop: 8 }}
        >
          {searching ? 'Ищем сервер…' : 'Найти сервер автоматически'}
        </button>

        {probes.length > 0 && (
          <div className="probe-list">
            {probes.map((r) => (
              <div key={r.url} className="probe">
                <span className={`status-dot ${r.ok ? 'status-dot--on' : 'status-dot--off'}`} />
                <span className="probe__url mono">{r.url}</span>
                <span className="probe__state">{r.ok ? `${r.ms} мс` : r.error}</span>
              </div>
            ))}
          </div>
        )}

        {health && (
          <>
            <div className="divider" />
            <div className="row" style={{ cursor: 'default' }}>
              <span className="status-dot status-dot--on" />
              <div className="row__body">
                <div className="row__title">Сервер отвечает</div>
                <div className="row__sub mono">{health.app} v{health.version}</div>
              </div>
              <span className="row__value">ok</span>
            </div>
            <div className="row" style={{ cursor: 'default' }}>
              <div className="row__body">
                <div className="row__title">SMS-провайдер</div>
                <div className="row__sub">{health.providerStatus?.detail || health.provider}</div>
              </div>
              <span className="row__value">{health.provider}</span>
            </div>
          </>
        )}

        <div className="divider" />
        <div className="section-title">Аккаунт</div>
        <button
          className="btn btn--danger"
          onClick={async () => {
            try {
              await api.logout();
            } catch {
              /* сервер может быть недоступен — всё равно выходим локально */
            }
            onLoggedOut();
            onToast('Вы вышли из аккаунта');
          }}
        >
          Выйти
        </button>

        <div className="footer-note">
          Astra 0.1.0 · тестовая версия
          <br />
          Вход по номеру телефона с SMS-кодом
        </div>
      </div>
    </>
  );
}
