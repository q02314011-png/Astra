/**
 * Поток событий сервера: сообщения и «прочитано» прилетают без перезапроса.
 *
 * Транспорт — обычный fetch с чтением тела потоком, а не WebSocket:
 * он не требует ни сервера с апгрейдом протокола, ни библиотеки, и
 * автоматически переподключается сам.
 */
import { getServerUrl, getToken, isLocalMode } from './api';
import type { RealtimeEvent } from './api';

type Handler = (e: RealtimeEvent) => void;

const RECONNECT_MIN = 1000;
const RECONNECT_MAX = 15_000;

let source: AbortController | null = null;
let retryDelay = RECONNECT_MIN;
let stopped = false;
const handlers = new Set<Handler>();

function base(): string {
  const t = getToken();
  // getServerUrl() сам подставит адрес по умолчанию, если пользователь
  // ещё не заходил в настройки — иначе адрес был бы пустой.
  const url = getServerUrl().replace(/\/+$/, '');
  return `${url}/api/events?token=${encodeURIComponent(t || '')}`;
}

async function loop() {
  // В автономном режиме сервера нет — подключаться не к чему.
  if (stopped || isLocalMode() || !getToken()) return;
  while (!stopped) {
    try {
      const ctrl = new AbortController();
      source = ctrl;

      const res = await fetch(base(), { signal: ctrl.signal, cache: 'no-store' });
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

      // Соединение есть — сбрасываем задержку переподключения.
      retryDelay = RECONNECT_MIN;

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        // Сервер пишет по одному JSON-объекту в строку. Heartbeat — пустые строки.
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('{')) continue;
          try {
            const evt = JSON.parse(trimmed) as RealtimeEvent;
            for (const h of handlers) h(evt);
          } catch {
            /* не наш кадр — пропускаем */
          }
        }
      }
    } catch (e: any) {
      if (stopped || e?.name === 'AbortError') break;
    } finally {
      source = null;
    }

    if (stopped) break;
    // Сервер мог быть недоступен — ждём и пробуем снова.
    await new Promise((r) => setTimeout(r, retryDelay));
    retryDelay = Math.min(retryDelay * 2, RECONNECT_MAX);
  }
}

/** Подписка на события. Возвращает функцию отписки. */
export function onRealtime(handler: Handler): () => void {
  handlers.add(handler);
  if (!source && !stopped) loop();
  return () => {
    handlers.delete(handler);
  };
}

/** Запускает поток. Вызывается один раз при входе. */
export function startRealtime(): void {
  stopped = false;
  if (!source) loop();
}

/** Останавливает поток — при выходе из аккаунта и при закрытии приложения. */
export function stopRealtime(): void {
  stopped = true;
  handlers.clear();
  source?.abort();
  source = null;
  retryDelay = RECONNECT_MIN;
}

/** Статус соединения для индикатора в интерфейсе. */
export function isRealtimeActive(): boolean {
  return Boolean(source);
}