export function Logo({ size = 92 }: { size?: number }) {
  return (
    <div className="logo" style={{ width: size, height: size }}>
      <svg className="logo__star" viewBox="0 0 24 24" width={size * 0.5} height={size * 0.5}>
        <path d="M12 1.6l2.47 6.02 6.53.5-4.94 4.3 1.5 6.42L12 15.5l-5.56 3.34 1.5-6.42-4.94-4.3 6.53-.5L12 1.6z" />
      </svg>
    </div>
  );
}

export function Wordmark({ tagline = 'мессенджер' }: { tagline?: string }) {
  return (
    <div className="wordmark">
      <div className="wordmark__name">Astra</div>
      <div className="wordmark__tag">{tagline}</div>
    </div>
  );
}
