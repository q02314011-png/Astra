import { useEffect, useRef, useState } from 'react';
import { api, ApiError, getCountry, type Chat } from '../api';
import { LOCAL_COUNTRIES } from '../api';
import { Avatar } from '../components/Avatar';
import { Banner } from '../components/Banner';
import { CountryPicker } from '../components/CountryPicker';
import { normalizeLocal } from '../phone';
import { onRealtime } from '../realtime';

function timeLabel(at: number): string {
  if (!at) return '';
  const d = new Date(at);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  const time = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  if (sameDay) return time;
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return `вчера ${time}`;
  return `${d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })} ${time}`;
}

export function ChatsScreen({
  onOpenChat,
  onBack,
  onToast,
  autonomous,
}: {
  onOpenChat: (chatId: string) => void;
  onBack: () => void;
  onToast: (m: string) => void;
  autonomous: boolean;
}) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');

  // ── начать чат по номеру ─────────────────────────────────────
  const [adding, setAdding] = useState(false);
  const [country, setCountryIso] = useState(getCountry());
  const [phone, setPhone] = useState('');
  const [searchBusy, setSearchBusy] = useState(false);
  const [searchErr, setSearchErr] = useState('');

  const load = async () => {
    if (autonomous) {
      setBusy(false);
      return;
    }
    setBusy(true);
    try {
      const res = await api.chats();
      setChats(res.chats);
      setError('');
    } catch (e) {
      setError((e as ApiError).message);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    load();
    if (autonomous) return;
    // Новое сообщение или «прочитано» — обновляем список, не перезапрашивая вручную.
    return onRealtime((evt) => {
      if (evt.type === 'message' || evt.type === 'read') load();
    });
  }, [autonomous]);

  const c = LOCAL_COUNTRIES.find((x) => x.code === country) || LOCAL_COUNTRIES[0];

  const startChat = async () => {
    setSearchErr('');
    const local = normalizeLocal(phone, c.code);
    if (!local || local.length < 4) {
      setSearchErr('Введите номер телефона');
      return;
    }
    setSearchBusy(true);
    try {
      const res = await api.openChat(`+${c.dial}${local}`, country);
      setAdding(false);
      setPhone('');
      onOpenChat(res.chat.id);
    } catch (e) {
      const err = e as ApiError;
      setSearchErr(err.message);
    } finally {
      setSearchBusy(false);
    }
  };

  return (
    <>
      <div className="header">
        <button className="header__back" onClick={onBack}>
          ‹
        </button>
        <div className="header__title">Чаты</div>
        <button className="header__action" onClick={() => setAdding((v) => !v)}>
          {adding ? 'Отмена' : 'Новый'}
        </button>
      </div>

      <div className="body">
        {autonomous && (
          <Banner kind="warn">
            Автономный режим — чатов нет. Переписка живёт на сервере: её видят оба
            участника, и она не пропадёт при смене устройства. Включи сервер в
            настройках, чтобы начать общаться.
          </Banner>
        )}

        {adding && !autonomous && (
          <>
            <div className="field">
              <label className="field__label">Номер телефона друга</label>
              <div className="input-group">
                <CountryPicker
                  value={country}
                  onChange={(iso) => {
                    setCountryIso(iso);
                  }}
                />
                <input
                  className={`input ${searchErr ? 'input--error' : ''}`}
                  inputMode="tel"
                  placeholder="000 000 00 00"
                  value={phone}
                  disabled={searchBusy}
                  onChange={(e) => setPhone(e.target.value.replace(/[^\d\s()\-]/g, ''))}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') startChat();
                  }}
                />
              </div>
              <div className="field__hint">
                Номер должен быть тем же, с которым друг вошёл в Astra.
              </div>
            </div>

            {searchErr && <Banner kind="error">{searchErr}</Banner>}

            <button
              className="btn"
              onClick={startChat}
              disabled={searchBusy || !phone.trim()}
              style={{ marginBottom: 12 }}
            >
              {searchBusy ? 'Ищем…' : 'Написать'}
            </button>
          </>
        )}

        {error && <Banner kind="error">{error}</Banner>}

        {busy ? (
          <div className="empty">
            <span className="spinner" />
          </div>
        ) : chats.length === 0 && !adding ? (
          <div className="empty">
            <div className="empty__icon">💬</div>
            <div className="empty__title">Здесь появятся диалоги</div>
            <div className="empty__text">
              Нажми «Новый» и введи номер друга. Он должен быть зарегистрирован
              в Astra на том же сервере.
            </div>
          </div>
        ) : (
          <div className="chat-list">
            {chats.map((chat) => (
              <button key={chat.id} className="chat-row" onClick={() => onOpenChat(chat.id)}>
                <Avatar
                  name={chat.peer?.name || '?'}
                  color={chat.peer?.avatarColor}
                />
                <div className="chat-row__body">
                  <div className="chat-row__top">
                    <span className="chat-row__name">{chat.peer?.name || 'Аккаунт удалён'}</span>
                    <span className="chat-row__time">
                      {timeLabel(chat.lastMessage?.at || chat.updatedAt)}
                    </span>
                  </div>
                  <div className="chat-row__bottom">
                    <span className={`chat-row__text${chat.unread ? ' chat-row__text--unread' : ''}`}>
                      {chat.lastMessage
                        ? `${chat.lastMessage.mine ? 'Вы: ' : ''}${chat.lastMessage.text}`
                        : 'Нет сообщений'}
                    </span>
                    {chat.unread > 0 && <span className="badge">{chat.unread}</span>}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </>
  );
}